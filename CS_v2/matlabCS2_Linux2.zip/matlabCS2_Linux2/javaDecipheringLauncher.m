function javaDecipheringLauncher(binPath, decipherClass, cipheringType, parametersPath, imToDecipherPath, ligne, colonne)
%% PARAMETERS TO CHANGE: 
% binPath = 'D:\ECLIPSE_PROJECT\Article4_QuantumCipherMode2\bin';
% decipherClass = 'main_pkg.DeCipher';
% cipheringType = 'PQAES_SHAKE';
% imToDecipherPath = '"C:\\Users\\Sitraka\\Documents\\MATLAB\\Simulaka mila vitaina\\output_java"';
% ligne = 192;
% colonne = 256;

    % Trouver le chemin du binaire java
    [status, javaPath] = system('find ~/.p2 -type f -name java | head -n 1');
    javaPath = strtrim(javaPath);  % on garde ce trim pour éviter les sauts de ligne

    if status ~= 0 || isempty(javaPath)
        error('Java executable not found via find.');
    end

    % Construire la commande sans nettoyage supplémentaire
    command = sprintf('"%s" -cp "%s" %s %s %s %s %d %d', ...
        javaPath, binPath, decipherClass, cipheringType, parametersPath, imToDecipherPath, ligne, colonne);

    % Exécuter et afficher la sortie
    [~, s] = system(command);
    disp(s)
end

