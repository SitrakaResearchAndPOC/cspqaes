function extrema = getExtrema(matrice)
%% get Min and Max of every plan of a multiplan matrice
%%
    [~,~,d] = size(matrice);
    extrema = zeros(d,2);
    for k = 1:d
        maxMat = max(max(matrice(:,:,k)));
        minMat = min(min(matrice(:,:,k)));
        extrema(k,:) = [maxMat,minMat];
    end
end