function image_stego_path = sendCS(imagePath,TS,cipherValue,repertoire_courant,dwtType,compressive_ratio,sampling_distance,imageHotePath)
%% PARAMETRES DE FONCTIONS :
% imagePath          : chemin complète de l'image à comprimer
% TS                 : valeur du treshold {min: 20; max: 200}
% cipherValue        : cipherValue{1 -> 'AES',2 ->'PQAES_SHA',3 -> 'PQAES_SHA3',4 -> 'PQAES_KECCAK',5 -> 'PQAES_SHAKE'};
% repertoire_courant : le dossier de travail
% dwtType            : type d'ondelette à utiliser {db1,db2,haar}
% compressive_ratio  : rapport de compression {.25;.5;.75}
% sampling_distance  : distance d'échantillonnage pour la matrice de mesure
% image_hote         : chemin vers l'image porteuse
%%

imgOrg    = double(imread(imagePath));                                                                                       
%% Paramètres à transferer au destinataire:
[ligne,colonne,profondeur] = size(imgOrg); 


%% PARAMETRES SYSTEMES :
binPath               = 'D:\ECLIPSE_PROJECT\Article4_QuantumCipherMode2\bin';
cipherClass           = 'main_pkg.Main';

%% CHOIX DU TYPE DE CHIFFREMENT:
cipherModes           = {'AES','PQAES_SHA','PQAES_SHA3','PQAES_KECCAK','PQAES_SHAKE'};
cipherMode            = cipherModes{cipherValue};

%% REPERTOIRES DE TRAVAIL:
input_java            = appendToPath(repertoire_courant,'input_java');
output_java           = appendToPath(repertoire_courant,'output_java');
S = abs(rand(4,1));
%% ************************************************************************

% LIGNES APRES COMPRESSION :
ligne_cr          = round(compressive_ratio * ligne);
% Sampling distance:


% 256 Bits = 32 blocks of 8 bits:
hash = DataHash(imgOrg,struct('Method','SHA-256'));
P    = getBitsWithHash(hash);

%% ****************** GENERATION DES PARAMETRES Q *************************
Q     = initialParameters(P,S);
x_0   = delimit(Q(1,:),colonne,1);
y_0   = delimit(Q(2,:),ligne,1) ;
g_0   = Q(3,:);
r     = Q(4,:);
%% ************************************************************************
%% ***************** GENERATION DE LA MATRICE SENSING *********************
sensing_matrix = sensingMatrix(ligne_cr,colonne,[sampling_distance;g_0;r]);
%% ***********************************************************************%

%% SPARSIFICATION EN UTILISANT LA TRANSFORMEE D'ONDELETTE - db2
Psi    = dwtmtx(colonne,dwtType,3);
imgSp  = zeros(ligne,colonne,profondeur);
for ii = 1:profondeur
    imgSp(:,:,ii) = Psi * imgOrg(:,:,ii) * Psi';
end
%% ************************************************************************

%% ********************** TRESHOLDING *************************************
imgSp(abs(imgSp) <= TS) = 0; 
%% ************************************************************************

%% CONFUSION ZIGZAG
imgZigzag =zeros(size(imgSp));
for ii = 1: profondeur
    imgZigzag(:,:,ii) =zigzag(imgSp(:,:,ii),x_0,y_0);
end
%% ************************************************************************

%% SCRAMBILG USING ARNOLD SCRAMBLING 
z1 = Lorenz_chaotic(0,2*ligne*colonne);
imgSpcon = zeros(size(imgZigzag));
for ii =1:profondeur
    imgSpcon(:,:,ii) = enscramble_arnold(imgZigzag(:,:,ii),z1);
end
%% ************************************************************************

%% COMPRESSIVE SENSING 
imgCS =zeros(ligne_cr,colonne,profondeur);
for ii =1:profondeur
    imgCS(:,:,ii) = sensing_matrix * imgSpcon(:,:,ii);    
end
%% ************************************************************************

%% QUANTIFICATION
img_en = zeros(ligne_cr,colonne,profondeur);
maxMin = [];
for ii = 1:profondeur
    max_tmp = max(max(imgCS(:,:,ii)));
    min_tmp = min(min(imgCS(:,:,ii)));
    tmp = [max_tmp,min_tmp];
    maxMin = cat(1,maxMin,tmp);
    img_en(:,:,ii) = round(255*(imgCS(:,:,ii) - min_tmp)  /(max_tmp - min_tmp));
end
%% ************************************************************************


%% TRANSFORM THE IMAGE TO BYTE
image = img_en - 128;
%% ************************************************************************

%% COLLAPSER LES 3 PLANS DE L'IMAGE
image_collapse = matriceCollapse(image);
%% **************** ATTENTION A LA NOUVELLE LIGNE*************************
[ligne_collapse,~] = size(image_collapse);
%% ***********************************************************************
 
%% ECRITURE DANS INPUT JAVA DE LA MATRICE QUANITFIE:
input_image_name = 'image.csv';
parent           = cd(input_java);
writematrix(image_collapse,input_image_name);
cd(parent);
%% ********************** CHEMIN DE L'IMAGE QUANTIFIE**********************
chemin_image_quantifie            = appendToPath(input_java,input_image_name);
%
%% Pour windows uniquement: 
chemin_image_quantifie_java       = normalizePathForJava(chemin_image_quantifie);
chemin_image_chiffree_java        = normalizePathForJava(output_java);
% 
%% ********************** PARTIE JAVA 1 ********************************* %%
% % javaCipheringLauncher(binPath,className,cipherType,input_path,output_path,ligne,colonne)
javaCipheringLauncher(binPath,cipherClass,cipherMode,chemin_image_quantifie_java,chemin_image_chiffree_java,ligne_collapse,colonne);

%% ******************** READ CIPHERED IMAGE OUTPUT BY JAVA ******************** 
chemin_image_chiffree = appendToPath(output_java,'imageCiphered');
parent = cd(chemin_image_chiffree);
imageCiphered = readmatrix('imageCiphered.csv');
cd(parent);
% 
%% *********************** 1 PLAN -> 3 PLANS *****************************%
imageCiphered = matriceDeCollapse(imageCiphered,profondeur);
imgCiphered = uint8(imageCiphered + 128);

%% ************************** STEGANOGRAPHIE*****************************%%
image_hote  = imread(imageHotePath);
bitsStego = 4;
image_stego= stegaInsertLSB(image_hote,imgCiphered,bitsStego);

%% *************** ECRITURE DE L'IMAGE STEGO *******************************
%% ***********************************************************************
dossier_des_resultats = appendToPath(repertoire_courant,'resultat_simulation');

if ~exist(dossier_des_resultats,'dir')
    mkdir(dossier_des_resultats);
end

timestamp = datestr(now,'ddmmyyyy_HHMMSS');
image_name = sprintf('image_%s.png',timestamp);

image_stego_path =sprintf('%s\\%s',dossier_des_resultats,image_name);
imwrite(image_stego,image_stego_path);
%% ************************* COMPARAISON IMAGE HOTE VS IMG STEGO *********%%
imageComparator(image_hote,image_stego,'Stéganography');

%% TANSMISSION DES VARIABLES POUR LA RECONSTRUCTION:
dossier_param = appendToPath(repertoire_courant,"params_rec");
if ~exist(dossier_param,'dir')
    mkdir(dossier_param);
end

% sur l'image source:
save(sprintf("%s\\%s",dossier_param,'imageSouceParameters.mat'),'ligne','colonne','profondeur','compressive_ratio','sampling_distance','cipherMode','imagePath');
% valeur du hash:
save(sprintf("%s\\%s",dossier_param,'hashImage.mat'),'hash');
% valeur des paramètres initiaux:
save(sprintf("%s\\%s",dossier_param,'initialParameters.mat'),'S');
% valeurs min et max de la quantification:
save(sprintf("%s\\%s",dossier_param,'quantification.mat'),'maxMin');
% le nom de fichier où image stégo est enregistré:
save(sprintf("%s\\%s",dossier_param,'imageStegoInfo.mat'),'dossier_des_resultats','image_name');
%% ************************************************************************
end