function imgIqua = invQuantification(imgQuan,extrema)
    [r_img,col_img,d_img]= size(imgQuan);
    [d_extrema,~,~]= size(extrema);
    if(d_img ~= d_extrema)
        error("Image and the extrema do not have the same dimension");
    end
    imgIqua = zeros(r_img,col_img,d_img);
    for ii = 1:d_img
        maxImg = extrema(ii,1);
        minImg = extrema(ii,2);
        imgIqua(:,:,ii) = imgQuan(:,:,ii) .* (maxImg - minImg)/255  + minImg;
    end
end