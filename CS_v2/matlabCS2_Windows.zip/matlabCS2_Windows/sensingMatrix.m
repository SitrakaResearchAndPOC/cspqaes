function matrice = sensingMatrix(m,n,parametresInitiaux)
%% m: le nombre de ligne de la matrice de mesures
%% n: le nombre de colonne de la matrice de mesures
%% parametresInitiaux: vecteur colonne contenant les paramètres [d,r,g0]
%% extraction des paramètres initiaux:
d  = parametresInitiaux(1,:);
r  = parametresInitiaux(2,:);
g0 = parametresInitiaux(3,:);

%% matrice de mesure
matrice = zeros(m,n);
indice = 1;
for ii= 1:n
    for jj = 1:m
        matrice(jj,ii)=1-2*chaoticSequence(indice,d,n,g0,r);
        indice =indice + 1;
    end
end 
    clear chaoticSequence;
end
