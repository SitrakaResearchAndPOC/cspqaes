%% ************************************************************************
%%                          PARTIE RECONSTRUCTION
%% ************************************************************************
%% CHEMINS:
repertoire_courant =pwd;
output_java   = appendToPath(repertoire_courant,'output_java');

%% Choix du Mode: Real ou Simulated
typeMode = Mode.Simulated;

%% LOADING DES PARAMETRES:

dossier_param = appendToPath("Resultat_Emission","params_rec");

% ligne, colonne, profondeur,
% compressive_ratio,sampling_distance,cipherMode
load(sprintf("%s\\%s",dossier_param,'imageSouceParameters.mat'));
% hash
load(sprintf("%s\\%s",dossier_param,'hashImage.mat'));
% S
load(sprintf("%s\\%s",dossier_param,'initialParameters.mat'));
% Quantification:[Maxmin]
load(sprintf("%s\\%s",dossier_param,'quantification.mat'));
%% ***********************************************************************

%% CALCUL DES PARAMETRES INITIAUX:
% 32 x 8 BITS:
P     = getBitsWithHash(hash);
% GENERATION DES PARAMETRES Q
Q     = initialParameters(P,S);
% x0,y0,g0,r
x_0   = delimit(Q(1,:),colonne,1);
y_0   = delimit(Q(2,:),ligne,1) ;
g_0   = Q(3,:);
r     = Q(4,:);
ligne_cr = compressive_ratio*ligne;
%% ***********************************************************************

%% MATRICE DE MESURE:
sensing_matrix = sensingMatrix(ligne_cr,colonne,[sampling_distance;g_0;r]);
%% ***********************************************************************
%% EXTRA
%% RECONSTRUCTION
Psi   = dwtmtx(colonne,'db1',3);
%% RECEPTION DES PARAMETRES NECESSAIRES:

%% ************************************************************************
%% STEGANOGRAPHIE - EXTRACTION
load(sprintf("%s\\%s",dossier_param,'imageStegoInfo.mat'));
imgStego = imread(sprintf('%s\\%s',dossier_des_resultats,image_name));
dim = [ligne_cr,colonne,profondeur];
imgRec = stegaExtractLSB(imgStego,dim,n);

imgRec = double(imgRec) - 128;
%% ************************************************************************
imgCollapse = matriceCollapse(imgRec);
ligne_collapse = size(imgCollapse,1);
%% CHIFFREMENT INVERSE :
%% ********************************************************************** %
chemin_image_a_dechiffrer = appendToPath(repertoire_courant,'imageToDecipher');
parent                    = cd(chemin_image_a_dechiffrer);
writematrix(imgCollapse,'imageToDecipher.csv');
cd(parent)
chemin_image_a_dechiffrer_java = appendToPath(chemin_image_a_dechiffrer,'imageToDecipher.csv');

%% PARAMETRES JAVA
binPath        = 'D:\ECLIPSE_PROJECT\Article4_QuantumCipherMode2\bin';
decipherClass  = 'main_pkg.DeCipher';
cipheringType  = cipherMode;
%% ****************************** MISE EN QUOTE ET DOUBLE SLASH **********%
parametersPath                 = normalizePathForJava(output_java);
chemin_image_a_dechiffrer_java = normalizePathForJava(chemin_image_a_dechiffrer_java);

%% *********************** DECHIFFREMENT JAVA*****************************%
javaDecipheringLauncher(binPath,decipherClass,cipheringType,parametersPath,chemin_image_a_dechiffrer_java,ligne_collapse,colonne);

%% *********************** LECTURE DU FINAL OUTPUT ***********************%
chemin_final_output = appendToPath(output_java,'finalOutput');
parent = cd(chemin_final_output);
image_collapse = readmatrix('finalOutput.csv');
cd(parent);

%% ************************** REDECOUPER EN 3 PLANS **********************%
img_en = matriceDeCollapse(image_collapse,profondeur);

%% *************************** DEQUANTIFICATION **************************%

%% ************************ BYTE -> NON-SIGNE ****************************%
img_en = img_en + 128; 

%% ************************ QUANTIFICATION *******************************

imgIqua = zeros(ligne_cr,colonne,profondeur);
for ii = 1:profondeur
    max_tmp = maxMin(ii,1);
    min_tmp = maxMin(ii,2);
    imgIqua(:,:,ii) = img_en(:,:,ii) * (max_tmp - min_tmp)/255 + min_tmp;
end

% imgIre = OMP_2D(imgIqua,sensing_matrix,ligne,colonne);
imgIre = zeros(ligne,colonne,profondeur);
for z = 1:profondeur
    for i = 1 : colonne                                                                                                                   % 列循环 
        imgIre(:,i,z) = OMP(imgIqua(:,i,z),sensing_matrix,round(ligne_cr/4)); 
    end
end

z1 = Lorenz_chaotic(0,2*ligne*colonne);
imgIcon = zeros(size(imgIre));
for ii = 1:profondeur
    imgIcon(:,:,ii) = descramble_arnold(imgIre(:,:,ii),z1);
end

for ii = 1:profondeur
    imgIcon(:,:,ii) = izigzag(imgIcon(:,:,ii),x_0,y_0);
end

imgIsp = zeros(size(imgIcon));

for ii = 1:profondeur
    imgIsp(:,:,ii) = Psi' * imgIcon(:,:,ii) * Psi;
end

img_de = uint8(imgIsp);

resultat_reception = 'Resultat_Reception';

if ~exist(resultat_reception,'dir')
    mkdir(resultat_reception)
end

cd(resultat_reception)
    imwrite(img_de,'image_reconstruite.png');
cd ..
%% AFFICHAGE DU RESULTAT FINAL
imgOrg = imread(imagePath);
if typeMode == Mode.Simulated
    imageComparator(imgOrg,img_de,'Final Result');
end
%% ***********************************************************************
%}