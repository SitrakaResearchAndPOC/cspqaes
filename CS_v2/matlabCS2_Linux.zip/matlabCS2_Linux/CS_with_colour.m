%% Lab 1:
imagePath = '.\images\download.jpeg';
imgOrg = double(imread(imagePath));                                                                                       
%% Paramètres à transferer au destinataire:
[ligne,colonne,profondeur] = size(imgOrg); 
TS = 25;
delta = 0;
cipherValue = 1;



%% Ciphering parameters:
binPath     = 'D:\ECLIPSE_PROJECT\Article4_QuantumCipherMode2\bin';
cipherClass = 'main_pkg.Main';
cipherModes = {'AES','PQAES_SHA','PQAES_SHA3','PQAES_KECCAK','PQAES_SHAKE'};
cipherMode  = cipherModes{cipherValue};
repertoire_courant    = pwd;
input_java = appendToPath(repertoire_courant,'input_java');
output_java   = appendToPath(repertoire_courant,'output_java');

%% 2- GET THE INITIAL PARAMETERS:
% S = [x0';y0';r;z0']
S = abs(rand(4,1));

% Compressive ratio:
compressive_ratio = 4/16;
ligne_cr          = round(compressive_ratio * ligne);
% Sampling distance:
sampling_distance = 20;
% 256 Bits = 32 blocks of 8 bits:
hash = DataHash(imgOrg,struct('Method','SHA-256'));
P = getBitsWithHash(hash);

%% ****************** GENERATION DES PARAMETRES Q *************************
Q   = initialParameters(P,S);
% Inutile --> Pour le zigzag:
x_0   = delimit(Q(1,:),colonne,1);
y_0   = delimit(Q(2,:),ligne,1) ;
g_0   = Q(3,:);
r     = Q(4,:);
%% ************************************************************************
%% ***************** GENERATION DE LA MATRICE SENSING *********************
sensing_matrix = sensingMatrix(ligne_cr,colonne,[sampling_distance;g_0;r]);
%% ***********************************************************************%

%% ******* SPARSIFICATION EN UTILISANT LA TRANSFORMEE D'ONDELETTE *********
Psi   = dwtmtx(colonne,'db2',3);
imgSp = zeros(ligne,colonne,profondeur);

for ii = 1:profondeur
    imgSp(:,:,ii) = Psi * imgOrg(:,:,ii) * Psi';
end
%% ************************************************************************

%% ********************** TRESHOLDING *************************************
imgSp(abs(imgSp) <= TS) = 0; 

%% CONFUSION ZIGZAG
imgZigzag =zeros(size(imgSp));
for ii = 1: profondeur
    imgZigzag(:,:,ii) =zigzag(imgSp(:,:,ii),x_0,y_0);
end
%% ************************************************************************

%% SCRAMBILG USING ARNOLD SCRAMBLING 
z1 = Lorenz_chaotic(0,2*ligne*colonne);
imgSpcon = zeros(size(imgZigzag));
for ii =1:profondeur
    imgSpcon(:,:,ii) = enscramble_arnold(imgZigzag(:,:,ii),z1);
end
%% ************************************************************************

%% COMPRESSIVE SENSING 
imgCS =zeros(ligne_cr,colonne,profondeur);
for ii =1:profondeur
    imgCS(:,:,ii) = sensing_matrix * imgSpcon(:,:,ii);    
end
%% ************************************************************************

%% QUANTIFICATION
img_en = zeros(ligne_cr,colonne,profondeur);
maxMin = [];
for ii = 1:profondeur
    max_tmp = max(max(imgCS(:,:,ii)));
    min_tmp = min(min(imgCS(:,:,ii)));
    tmp = [max_tmp,min_tmp];
    maxMin = cat(1,maxMin,tmp);
    
    img_en(:,:,ii) = round(255*(imgCS(:,:,ii) - min_tmp)  /(max_tmp - min_tmp));
end
%% ************************************************************************


%% TRANSFORM THE IMAGE TO BYTE
image = img_en - 128;
%% ************************************************************************

%% COLLAPSER LES 3 PLANS DE L'IMAGE
image_collapse = matriceCollapse(image);
%% **************** ATTENTION A LA NOUVELLE LIGNE*************************
[ligne_collapse,~] = size(image_collapse);
%% ***********************************************************************
 
%% ECRITURE DANS INPUT JAVA DE LA MATRICE QUANITFIE:
input_image_name = 'image.csv';
parent           = cd(input_java);
writematrix(image_collapse,input_image_name);
cd(parent);
%% ********************** CHEMIN DE L'IMAGE QUANTIFIE**********************
chemin_image_quantifie            = appendToPath(input_java,input_image_name);
%
%% Pour windows uniquement: 
chemin_image_quantifie_java       = normalizePathForJava(chemin_image_quantifie);
chemin_image_chiffree_java        = normalizePathForJava(output_java);
% 
%% ********************** PARTIE JAVA 1 ********************************* %%
% % javaCipheringLauncher(binPath,className,cipherType,input_path,output_path,ligne,colonne)
javaCipheringLauncher(binPath,cipherClass,cipherMode,chemin_image_quantifie_java,chemin_image_chiffree_java,ligne_collapse,colonne);

%% ******************** READ CIPHERED IMAGE OUTPUT BY JAVA ******************** 
chemin_image_chiffree = appendToPath(output_java,'imageCiphered');
parent = cd(chemin_image_chiffree);
imageCiphered = readmatrix('imageCiphered.csv');
cd(parent);
% 
%% *********************** 1 PLAN -> 3 PLANS *****************************%
imageCiphered = matriceDeCollapse(imageCiphered,profondeur);
%% UTILISATION DE LA STEGANOGRAPHIE/ INSERTION:
%{
    choix de l'image porteuse:
    - nombres de lignes   : 4 x ligne_cr
    - nombres de colonnes : même que celui de l'image compressé 
%}
%% ************************** STEGANOGRAPHIE*****************************%%
image_hote  = imread('.\images\image.png');
[image_stego,IT] = StegaTest(image_hote,imageCiphered);

%% *************** ECRITURE DE L'IMAGE STEGO *******************************
[l_stego,c_stego,d_stego] = size(image_stego);
output = matriceCollapse(image_stego);
writematrix(output,'image_stego.csv');
imageComparator(image_hote,image_stego,'Stéganography');
%% ***********************************************************************



%% ************************* COMPARAISON IMAGE HOTE VS IMG STEGO *********%%



%% ************************************************************************
%%                          PARTIE RECONSTRUCTION
%% ************************************************************************
output = readmatrix('image_stego.csv');
image_stego = matriceDeCollapse(output,d_stego);
imgRec = InvStegaTest(image_stego,IT);


%% ****************** 3 PLANS -> 1 PLAN ********************************* %
image_collapse = matriceCollapse(imgRec);
[ligne_collapse,~] = size(image_collapse);

%% ********************************************************************** %
chemin_image_a_dechiffrer = appendToPath(repertoire_courant,'imageToDecipher');
parent                    = cd(chemin_image_a_dechiffrer);
writematrix(image_collapse,'imageToDecipher.csv');
cd(parent)
chemin_image_a_dechiffrer_java = appendToPath(chemin_image_a_dechiffrer,'imageToDecipher.csv');

%% PARAMETRES JAVA
binPath        = 'D:\ECLIPSE_PROJECT\Article4_QuantumCipherMode2\bin';
decipherClass  = 'main_pkg.DeCipher';
cipheringType  = cipherMode;
%% ****************************** MISE EN QUOTE ET DOUBLE SLASH **********%
parametersPath                 = normalizePathForJava(output_java);
chemin_image_a_dechiffrer_java = normalizePathForJava(chemin_image_a_dechiffrer_java);

%% *********************** DECHIFFREMENT JAVA*****************************%
javaDecipheringLauncher(binPath,decipherClass,cipheringType,parametersPath,chemin_image_a_dechiffrer_java,ligne_collapse,colonne);

%% *********************** LECTURE DU FINAL OUTPUT ***********************%
chemin_final_output = appendToPath(output_java,'finalOutput');
parent = cd(chemin_final_output);
image_collapse = readmatrix('finalOutput.csv');
cd(parent);

%% ************************** REDECOUPER EN 3 PLANS **********************%
img_en = matriceDeCollapse(image_collapse,profondeur);

%% *************************** DEQUANTIFICATION **************************%

%% ************************ BYTE -> NON-SIGNE ****************************%
img_en = img_en + 128; 

%% ************************ QUANTIFICATION *******************************
imgIqua = zeros(ligne_cr,colonne,profondeur);
for ii = 1:profondeur
    max_tmp = maxMin(ii,1);
    min_tmp = maxMin(ii,2);
    imgIqua(:,:,ii) = img_en(:,:,ii) * (max_tmp - min_tmp)/255 + min_tmp;
end

% imgIre = OMP_2D(imgIqua,sensing_matrix,ligne,colonne);
imgIre = zeros(ligne,colonne,profondeur);
for z = 1:profondeur
    for i = 1 : colonne                                                                                                                   % 列循环 
        imgIre(:,i,z) = OMP(imgIqua(:,i,z),sensing_matrix,round(ligne_cr/4)); 
    end
end

%z2 = Lorenz_chaotic(0,2*ligne*colonne);
imgIcon = zeros(size(imgIre));
for ii = 1:profondeur
    imgIcon(:,:,ii) = descramble_arnold(imgIre(:,:,ii),z1);
end

for ii = 1:profondeur
    imgIcon(:,:,ii) = izigzag(imgIcon(:,:,ii),x_0,y_0);
end

imgIsp = zeros(size(imgIcon));

for ii = 1:profondeur
    imgIsp(:,:,ii) = Psi' * imgIcon(:,:,ii) * Psi;
end

img_de = uint8(imgIsp);
%% ***********************************************************************
imageComparator(imgOrg,img_de,'Final Result');
%% ***********************************************************************
