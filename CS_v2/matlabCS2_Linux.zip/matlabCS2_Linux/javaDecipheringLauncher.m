function javaDecipheringLauncher(binPath, decipherClass, cipheringType, parametersPath, imToDecipherPath, ligne, colonne)
    % Trouver le chemin du binaire java
    [status, javaPath] = system('find ~/.p2 -type f -name java | head -n 1');
    javaPath = strtrim(javaPath);  % on garde ce trim pour éviter les sauts de ligne

    if status ~= 0 || isempty(javaPath)
        error('Java executable not found via find.');
    end

    % Construire la commande sans nettoyage supplémentaire
    command = sprintf('"%s" -cp "%s" %s %s %s %s %d %d', ...
        javaPath, binPath, decipherClass, cipheringType, parametersPath, imToDecipherPath, ligne, colonne);

    % Exécuter et afficher la sortie
    [~, s] = system(command);
    disp(s)
end

