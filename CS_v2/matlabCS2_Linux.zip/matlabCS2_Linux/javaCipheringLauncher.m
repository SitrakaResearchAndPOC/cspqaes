function javaCipheringLauncher(binPath,className,cipherType,input_path,output_path,ligne,colonne)
%% PARAMETERS TO CHANGE: 
    command = sprintf('/root/.p2/pool/plugins/org.eclipse.justj.openjdk.hotspot.jre.full.linux.x86_64_17.0.11.v20240426-1830/jre/bin/java -cp %s %s %s %s %s %d %d',binPath, className,cipherType,input_path,output_path,ligne,colonne);
    [~,s] = system(command);
    disp(s)
end
