function javaCipheringLauncher(binPath, className, cipherType, input_path, output_path, ligne, colonne)
    % Récupérer le chemin complet de java via la commande Linux
    [status, javaPath] = system('find ~/.p2 -type f -name java | head -n 1');

    % Nettoyer les éventuels sauts de ligne
    javaPath = strtrim(javaPath);

    % Vérification de la détection
    if status ~= 0 || isempty(javaPath)
        error('Java executable not found in ~/.p2');
    end
    % disp(javaPath);
    
    % Construction de la commande complète
    command = sprintf('"%s" -cp "%s" %s %s %s %s %d %d', javaPath, binPath, className, cipherType, input_path, output_path, ligne, colonne);
    % disp(command);
    % Exécution
    [~, s] = system(command);
    disp(s)
end

