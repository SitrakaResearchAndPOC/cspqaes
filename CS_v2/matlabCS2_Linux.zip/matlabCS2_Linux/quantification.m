function imgQuan = quantification(img,extrema)
    [r_img,col_img,d_img]= size(img);
    [d_extrema,~,~]= size(extrema);
    if(d_img ~= d_extrema)
        error("Image and the extrema do not have the same dimension");
    end
    imgQuan = zeros(r_img,col_img,d_img);
    for ii = 1:d_img
        maxImg = extrema(ii,1);
        minImg = extrema(ii,2);
        imgQuan(:,:,ii) = round(255*(img(:,:,ii) - minImg)  /(maxImg - minImg));
    end
    
end