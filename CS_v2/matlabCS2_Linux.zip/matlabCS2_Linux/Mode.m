classdef Mode
    enumeration
        Real,
        Simulated
    end
end
            