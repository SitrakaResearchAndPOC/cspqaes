function bits = getBitsWithHash(hash)
bits = zeros(32,8);
for ii = 1:32
    init = 2*(ii-1)+1 ;
    final = 2*ii;
    hexValue = hash(init:final);
    binValue = dec2bin(hex2dec(hexValue),8);
    bits(ii,:) = str2num(binValue(:))';
end
end
