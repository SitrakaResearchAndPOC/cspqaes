function image = BP_2D(img_compressed,phi,ligne,colonne)
image = zeros(ligne,colonne);
for i=1:colonne
  image(:,i) = cs_bp(img_compressed(:,i),phi);
end