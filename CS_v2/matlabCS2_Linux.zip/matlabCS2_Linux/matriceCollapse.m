function collapse = matriceCollapse(matrice)
    [l,c,d] = size(matrice);
    ligne = l*d;
    collapse = zeros(ligne,c);
    for ii = 1:d
        start_idx = (ii - 1)*l+1;
        end_idx   = ii*l; 
        collapse(start_idx:end_idx,:) = matrice(:,:,ii);
    end
end