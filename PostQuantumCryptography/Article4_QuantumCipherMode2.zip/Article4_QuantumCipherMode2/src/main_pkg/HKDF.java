package main_pkg;

/*create by sitraka  29/12/2022*/
public class HKDF {
	String info;
	String info_final;
	int length_hash;
	byte prk [];
	public HKDF(String info, int length_hash) {
		// TODO Auto-generated constructor stub
		this.info = info;
		//expandable 256 bit for the other "sha", "keccak",  "sha3": 
		if((this.info =="sha")||(this.info =="SHA")) {
			if(length_hash >= 1024) {
				this.length_hash = 256;
			}else {
				this.length_hash = length_hash;	
			}
		}else if((this.info =="keccak")||(this.info =="KECCAK")||(this.info =="Keccak")) {
			if(length_hash >= 1024) {
				this.length_hash = 256;
			}else {
				this.length_hash = length_hash;	
			}
		}else 	if((this.info =="sha3")||(this.info =="SHA3")) {
			if(length_hash >= 1024) {
				this.length_hash = 256;
			}else {
				this.length_hash = length_hash;	
			}
		}else {
			this.length_hash = length_hash;			
		}
//		this.length_hash = length_hash;		
		
		this.info_final = this.info+"_"+length_hash;
		//System.out.println("info_final : "+ this.info_final);
	}

	
	
	   public byte[] createKey() {
	        byte key[] = new byte[length_hash/8];
	        java.util.Random rndGen = new java.util.Random();
	        rndGen.nextBytes(key);
	        return key;
	    }
	   
	   
	/*inspired on java code stackoverflow*/
	   public static String toHexString2(byte[] bytes) {
	        char[] hexArray = "0123456789ABCDEF".toCharArray();
	        char[] hexChars = new char[bytes.length * 2];
	        for (int j = 0; j < bytes.length; j++) {
	            int v = bytes[j] & 0xFF;
	            hexChars[j * 2] = hexArray[v >>> 4];
	            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
	        }
	        return new String(hexChars);
	    }
	    
	    
	    public static String toHexString(byte[] byteArray)
	    {
	        String hex = "";
	  
	        // Iterating through each byte in the array
	        for (byte i : byteArray) {
	            hex += String.format("%02X", i);
	        }
	  
	        //System.out.print(hex);
	        return hex;
	    }
	    /*inspired at : https://www.geeksforgeeks.org/java-program-to-convert-hex-string-to-byte-array/*/
	    public byte[] toStringHex(String key) {
	    	 int len = key.length();
	         byte[] ans = new byte[len / 2];
	        
	         for (int i = 0; i < len; i += 2) {
	              // using left shift operator on every character
	             ans[i / 2] = (byte) ((Character.digit(key.charAt(i), 16) << 4)
	                     + Character.digit(key.charAt(i+1), 16));
	         }
	         /*System.out.print("Byte Array : ");
	           
	         for(int i=0;i<ans.length;i++){
	             System.out.print(ans[i]+" ");
	         }
	         System.out.println("");
	         */
	         return ans;	    	
	    }

	    
	    /*xor array bytes : https://programming-idioms.org/idiom/238/xor-byte-arrays/5801/java*/
	public byte [] bytes_arrays_xor(byte []input1, byte [] input2){
		byte[] result = new byte[input1.length];
		if(input1.length != input2.length) {
			return null;
		}else {
			for (int i = 0; i < input1.length; i++) {
			  result[i] = (byte) (input1[i] ^ input2[i]);
			}
			
		}
		return result;
	}
	
	public byte [] bytes_arrays_concat(byte[] input1, byte[] input2) {
		if(input1 == null && input2 == null) {
			return null;
		}else if(input1 == null) {
			return input2;
		}else if (input2 == null) {
			return input1;
		}else {
		    int len1 = input1.length;
		    int len2 = input2.length;
		    
		    byte[] res = new byte[len1 + len2];
			for(int i = 0; i <len1; i++) {
				res[i] = input1[i];
			}
			for(int i = 0; i < len2; i++) {
				res[i+len1] = input2[i];
			}
			return res;		
		}
	}

	public byte [] bytes_arrays_concat4(byte[] input1, byte[] input2, byte[] input3, byte[] input4) {
		byte []res = new byte[input1.length+input2.length+input3.length+input4.length];
		for(int i = 0; i < input1.length; i++) {
			res[i] = input1[i];
		}
		for(int i = 0; i < input2.length; i++) {
			res[i+input1.length] = input2[i];
		}
		
		for(int i = 0; i < input3.length; i++) {
			res[i+input1.length+input2.length] = input3[i];
		}
		for(int i = 0; i < input4.length; i++) {
			res[i+input1.length+input2.length+input3.length] = input4[i];
		}

		return res;
	}
	public byte [] bytes_arrays_addOne(byte []input){
		byte ret = 1;
		byte []output = new byte[input.length];
		for(int i=input.length-1; i >=0; i--) {
			output[i] = (byte) (input[i]+(byte) ret);
			if((output[i] == 0)&&(ret == 1)) {
				ret = 1;
			}else {
				ret = 0;
			}
		}
		if(ret == 1) {
			byte[] output2 = new byte[input.length+1];
			output2[0] = 1;
			for(int i = 0; i < output.length; i++) {
				output2[i+1] = output[i];
			}
			return output2;
		}
		return output;
	}

	
	
	
	public byte [] extract(String ikm) {
		/*verify length key*/
		//System.out.println("ikm length "+ikm.length());
		//System.out.println("length hash : "+(length_hash/8));
		if(ikm.length() < (length_hash/4)) {
			System.out.println("Error length key");
			return null;
		}
		return extract(toStringHex(ikm));
	}

	public byte[] extract(byte  []ikm) {
		/*initialize salt by zero*/
		if(ikm.length < (length_hash/8)) {
			System.out.println("Error length key");
			return null;
		} else if(ikm.length == length_hash/8) {
			byte salt[] = new byte [(length_hash/8)];
			
			for(int i = 0; i < salt.length; i++) {
				salt[i] = 0;
			}
			
			HMAC hash_mac = new HMAC(info, length_hash);
			//System.out.println("hmac :: "+info+"_"+length_hash);
			//System.out.println("salt :: "+toHexString(salt));
			//System.out.println("ikm :: "+toHexString(ikm));

			this.prk = hash_mac.do_final(salt, ikm);
			//System.out.println("PRK : "+toHexString(prk));
			return this.prk;
			
		}else {	
			byte salt[] = new byte [ikm.length];
			for(int i = 0; i < salt.length; i++) {
				salt[i] = 0;
			}
		
			HMAC hash_mac = new HMAC(info, length_hash);
			//System.out.println("hmac :: "+info+"_"+length_hash);
			//System.out.println("salt :: "+toHexString(salt));
			//System.out.println("ikm :: "+toHexString(ikm));

			this.prk = hash_mac.do_final(salt, ikm);
			//System.out.println("PRK : "+toHexString(prk));
			return this.prk;
		}
		

	}
	public byte [] expand(int L, String ikm) {
		if(ikm.length() != (length_hash/4)) {
			System.out.println("Error length key");
			return null;
		}
		return expand(L, toStringHex(ikm));
	}		
	
	
	public byte [] expand(int L, byte[] ikm) {
		this.prk = extract(ikm);
		int N = (int) Math.ceil ((double)L/length_hash);
		//System.out.println("CEIL : "+N);
		byte T[] = new byte [(length_hash/8)];
	    
		//intialize T by zero
		for(int i = 0; i < T.length; i++) {
			T[i] = 0;
		}
		byte []cmpt = new byte[1];
		cmpt[0] = 0;
		byte []result = null;
		HMAC hmac = new HMAC(info, length_hash);
		for (int i = 0; i <  N; i++) {
			cmpt = bytes_arrays_addOne(cmpt);
			/*byte []msg = bytes_arrays_concat(prk, T);
			msg = bytes_arrays_concat(msg, info.getBytes());			
			msg = bytes_arrays_concat(msg, cmpt);*/
			byte []msg = bytes_arrays_concat4(prk, T, info_final.getBytes(), cmpt);			
			T = hmac.do_final(msg, ikm);
			result = bytes_arrays_concat(result, T);
		}
		return result;
	}
	
}
