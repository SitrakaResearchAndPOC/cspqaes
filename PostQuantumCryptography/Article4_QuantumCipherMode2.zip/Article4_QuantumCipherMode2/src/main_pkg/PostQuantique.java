package main_pkg;

import java.io.Serializable;

public interface PostQuantique extends Serializable {
	public int[] createKeyExpansion(int length_hash);
	public byte[][] invCipher(byte[][] imageEncrypted,int[] wordsKeyExpansion);
	public byte[][] cipher(byte[][] image,int[]wordsKeyExpansion);
}
