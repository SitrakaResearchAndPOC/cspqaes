package main_pkg;

public class PQAES_SHA3 implements PostQuantique {
	/**
	 * 
	 */
	private PQ_AES paes_sha3; 
	public PQAES_SHA3(int blockLength) {
		paes_sha3 = new PQ_AES(blockLength);
		paes_sha3.set_info("sha3");
	}
	public byte[] createKey() {
		return paes_sha3.createKey();	
	}
	public void setkey(byte [] key) {
		paes_sha3.setkey(key);
	}
	public int[] createKeyExpansion(int length_hash) {
		return paes_sha3.createKeyExpansion("sha", length_hash);
	}
	public byte[][] cipher(byte[][] image,int[]wordsKeyExpansion) {
		
		byte[][] imageEncrypted = new byte[image.length][];
		int i = 0;
		for(byte [] tmp:image) {
			byte[] tmpEncrypted = paes_sha3.cipher(tmp, wordsKeyExpansion);
			imageEncrypted[i] = tmpEncrypted;
			i++;
		}
		
		return imageEncrypted; 
	}
	public byte[][] invCipher(byte[][] imageEncrypted,int[] wordsKeyExpansion) {
		
		byte[][] image = new byte[imageEncrypted.length][];
		int i = 0;
		for(byte [] tmpEncrypted:imageEncrypted) {
			byte[] tmp = paes_sha3.invCipher(tmpEncrypted, wordsKeyExpansion);
			image[i] = tmp;
			i++;
		}
		return image;
	}
	public static void main(String[] args) {
		byte[][] image =new byte[][] {
			{1,2,3},
			{4,5,6},
			{7,8,9}
		};
		PQAES_SHA paes_sha3 = new PQAES_SHA(PQ_AES.KEY_SIZE_256);
		byte[] cle = paes_sha3.createKey();
		paes_sha3.setkey(cle);
		int[] keyExpansion = paes_sha3.createKeyExpansion(PQ_AES.KEY_SIZE_256);
		byte[][] imageCiphered = paes_sha3.cipher(image, keyExpansion);
		byte[][] imageDeciphered =paes_sha3.invCipher(imageCiphered, keyExpansion);
		System.out.println("image ciphered");
		ReadCSV.displayMatrice(image);
		System.out.println("");
		
		System.out.println("image ciphered");
		ReadCSV.displayMatrice(imageCiphered);
		
		System.out.println("");
		System.out.println("image reconstructed");
		ReadCSV.displayMatrice(imageDeciphered);
}
}
