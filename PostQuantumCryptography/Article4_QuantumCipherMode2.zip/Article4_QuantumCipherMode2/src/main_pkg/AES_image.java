package main_pkg;

import java.io.IOException;

public class AES_image extends AES {
	/* M�thodes utiles
	 * generation de la cl�
	 * chiffrement et d�chiffrement
	 * */
	
	public AES_image() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public AES_image(int iBlockLength ) {
		super(iBlockLength);
	}
	
	
	public byte[][] cipher(byte[][] image,int[]wordsKeyExpansion) {
		
		byte[][] imageEncrypted = new byte[image.length][];
		int i = 0;
		for(byte [] tmp:image) {
			byte[] tmpEncrypted = this.cipher(tmp, wordsKeyExpansion);
			imageEncrypted[i] = tmpEncrypted;
			i++;
		}
		
		return imageEncrypted;
	}
	public byte[][] invCipher(byte[][] imageEncrypted,int[] wordsKeyExpansion) {
		
		byte[][] image = new byte[imageEncrypted.length][];
		int i = 0;
		for(byte [] tmpEncrypted:imageEncrypted) {
			byte[] tmp = this.invCipher(tmpEncrypted, wordsKeyExpansion);
			image[i] = tmp;
			i++;
		}
		return image;
	}
	
	public static void main(String[] args) throws IOException {
		String chemin = "C:\\Users\\Sitraka\\Documents\\MATLAB\\Simulaka mila vitaina\\imageTest.csv";
		String chemin_2 = "C:\\Users\\Sitraka\\Documents\\MATLAB\\Simulaka mila vitaina";
		
		byte[][] image = CSVProcessor.readCSV(chemin, new int[] {256,256});
		AES_image aes = new AES_image(AES.KEY_SIZE_256);
		byte[] cle = aes.createKey();
		int[] keyExpansion = aes.createKeyExpansion(cle);
		byte[][] imageCiphered = aes.cipher(image, keyExpansion);
		byte[][] imageDeciphered =aes.invCipher(imageCiphered, keyExpansion);
		System.out.println("image ciphered");
		ReadCSV.displayMatrice(image,10,10);
		System.out.println("");
		
		System.out.println("image ciphered");
		ReadCSV.displayMatrice(imageCiphered,10,10);
		

		System.out.println("");
		System.out.println("image reconstructed");
		ReadCSV.displayMatrice(imageDeciphered,10,10);
		
		CSVProcessor.writeCSV(imageDeciphered, chemin_2, "imageReconstruit.csv");
	}
	
}
