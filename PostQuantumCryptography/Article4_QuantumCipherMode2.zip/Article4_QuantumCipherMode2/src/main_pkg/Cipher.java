package main_pkg;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Cipher {
	public static boolean writeInt(int[] data,File fichier) throws Exception{
		try(DataOutputStream out = new DataOutputStream(new FileOutputStream(fichier))){
			for(int i:data) {
				System.out.print(i+" ");
				out.writeInt(i);
			}	
			System.out.println(" ");
			return true;
		}catch(IOException e) {
			System.out.println("Ecriture impossible!");
			return false;
		}
	}
	public static boolean writeByte(byte[] data,File fichier) throws Exception{
		try(DataOutputStream out = new DataOutputStream(new FileOutputStream(fichier))){
			for(byte i:data) {
				System.out.print(i+" ");
				out.writeByte(i);
			}	
			System.out.println(" ");
			return true;
		}catch(IOException e) {
			System.out.println("Ecriture impossible!");
			return false;
		}
	}
	
	
	public static void fileInfo(File file) {
		System.out.println("Fichier: "+ file.getName());
		if(file.exists()) {
			System.out.println("Le Fichier existe.");
			if(file.isDirectory())
				System.out.println("C'est un dossier.");
			else
				System.out.println("C'est un fichier!");
		}
		else {
			System.out.println("Fichier introuvable!");
		}
			
	}
	public static void main(String[] args) throws Exception  {
		long start = System.currentTimeMillis();
		
		if(args.length < 5) {
			System.out.println("Program successfully compiled!");
			System.exit(0);
		}
		
		// LES VARIABLES D'ENVIRONNEMENT:
		String type_chiffrement = args[0];
		String input_path       = args[1];
		String output_path		= args[2];
		int ligne				= Integer.parseInt(args[3]);
		int colonne				= Integer.parseInt(args[4]);
		
		System.out.printf("Arguments:\n- Ciphering Mode: %s\n"
				+ "- Input Path: %s\n"
				+ "- Output Path: %s\n"
				+ "- Image Size:[%03d, %03d]\n",type_chiffrement,input_path,output_path,ligne,colonne);
		
		
		
		byte[][] image         = CSVProcessor.readCSV(input_path, new int[] {ligne,colonne});
		byte[][] imageCiphered = null; 
		byte[] cle             = null;
		int[] keyExpansion     = null;
		
		switch(type_chiffrement) {
			case "AES"       -> {	
				System.out.println("image entrant");
				ReadCSV.displayMatrice(image, 10, 10);
	
				AES_image aes = new AES_image(AES.KEY_SIZE_256);
				cle           = aes.createKey();
				keyExpansion  = aes.createKeyExpansion(cle);
				imageCiphered = aes.cipher(image, keyExpansion);

				System.out.println("image ciphered");
				ReadCSV.displayMatrice(imageCiphered, 10, 10);
				/*cote dechiffrement*/
			/*	AES_image aes2 = new AES_image(AES.KEY_SIZE_256);
				aes2.setkey(cle);
				keyExpansion = aes2.createKeyExpansion(cle);
				byte[][] image_mitovy = aes2.invCipher(imageCiphered, keyExpansion);
				
				System.out.println("Image originale : ");
				ReadCSV.displayMatrice(image, 10, 10);
				System.out.println("Image rec : ");
				ReadCSV.displayMatrice(image_mitovy, 10, 10);
			*/	
			}
			case "PQAES_SHA" ->{
				PQAES_SHA pqaes_sha = new PQAES_SHA(PQ_AES.KEY_SIZE_256);
				cle                 = pqaes_sha.createKey();
				pqaes_sha.setkey(cle);
				keyExpansion        = pqaes_sha.createKeyExpansion(PQ_AES.KEY_SIZE_256);
				imageCiphered       = pqaes_sha.cipher(image, keyExpansion);
			}
			case "PQAES_SHA3" ->{
				PQAES_SHA paes_sha3 = new PQAES_SHA(PQ_AES.KEY_SIZE_256);
				cle = paes_sha3.createKey();
				paes_sha3.setkey(cle);
				keyExpansion        = paes_sha3.createKeyExpansion(PQ_AES.KEY_SIZE_256);
				imageCiphered       = paes_sha3.cipher(image, keyExpansion);
			}
			case "PQAES_KECCAK"->{
				PQAES_KECCAK paes_keccak = new PQAES_KECCAK(PQ_AES.KEY_SIZE_256);
				cle = paes_keccak.createKey();
				paes_keccak.setkey(cle);
				keyExpansion             = paes_keccak.createKeyExpansion(PQ_AES.KEY_SIZE_256);
				imageCiphered            = paes_keccak.cipher(image, keyExpansion);
			}
			case "PQAES_SHAKE" ->{
				PQAES_SHAKE paes_shake = new PQAES_SHAKE(PQ_AES.KEY_SIZE_256);
				cle = paes_shake.createKey();
				paes_shake.setkey(cle);
				keyExpansion           = paes_shake.createKeyExpansion(PQ_AES.KEY_SIZE_256);
				imageCiphered          = paes_shake.cipher(image, keyExpansion);
			}
		}
		System.out.println("Ciphering done!");
		/********************************************************************************************************************/
		// Ecriture des param�tres n�cessaires:
		// 1 -> cle
		File cleFile =new File(output_path+File.separator+"cle");
		if(!cleFile.exists())
			cleFile.mkdir();
		
		File cleData = new File(cleFile.toString()+File.separator+"cle.dat");	
		if(writeByte(cle, cleData)) {
			System.out.println("Writing cle done!");
		}
				
		// 2 -> keyExpansion
		File keyExpansionFile =new File(output_path+File.separator+"keyExpansion");
		if(!keyExpansionFile.exists())
			keyExpansionFile.mkdir();
		
		File keyExpansionData = new File(keyExpansionFile.toString()+File.separator+"keyExpansion.dat");
		if(writeInt(keyExpansion, keyExpansionData)) {
			System.out.println("Writing The Key Expansion done!");
		}
		// 3 -> imageCSV
		File imageCipheredFile = new File(output_path+File.separator+"imageCiphered");
		if(!imageCipheredFile.exists())
			imageCipheredFile.mkdir();
		String fileName = "imageCiphered.csv";
		CSVProcessor.writeCSV(imageCiphered, imageCipheredFile.toString(),fileName);
		
		
		long end = (System.currentTimeMillis()-start);
		System.out.println("Task done, time required :" +end+" ms!");
	}
}
