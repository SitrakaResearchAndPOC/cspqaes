package main_pkg;

import java.io.File;
import java.util.Scanner;

public class Programme {

	public static void main(String[] args)throws Exception {
		// Ciphering objects:
		AES_image aes = new AES_image(AES.KEY_SIZE_256);
		PQAES_SHA paes_sha = new PQAES_SHA(PQ_AES.KEY_SIZE_256);
		PQAES_SHA paes_sha3 = new PQAES_SHA(PQ_AES.KEY_SIZE_256);
		PQAES_SHAKE paes_shake = new PQAES_SHAKE(PQ_AES.KEY_SIZE_256);
		PQAES_KECCAK paes_keccak = new PQAES_KECCAK(PQ_AES.KEY_SIZE_256);
		// D�fifition des chemins
		
		String in ="entree"+File.separator;
		String out ="sortie"+File.separator;

		// Lecture de l'image csv
		int choixMethode = 0;
		int[] dim =Parametres.dimension();
		// 
		String pathIn = in +"image_quantifie.csv";
		byte[][] imageCSV = CSVProcessor.readCSV(pathIn, dim);
		
		// imageCSV is a byte
		// Variables utiles:
		byte[][] imageCiphered = null;
		int[] keyExpansion = null;
		byte[] cle;
		// chiffrement
		Scanner sc = new Scanner(System.in);
		System.out.println("""
		Choose Ciphering methods:\n
				1 - AES\n
				2 - PQAES SHA\n
				3 - PQAES SHA3
				4 - PQAES Keccak\n 		
				5 - PQAES Shake\n 		
		""");
		System.out.print("Method number: ");
		choixMethode = sc.nextInt();
		switch(choixMethode) {
		case 1:
			cle = aes.createKey();
			keyExpansion = aes.createKeyExpansion(cle);
			imageCiphered = aes.cipher(imageCSV, keyExpansion);
			break;
			
		case 2:
			cle = paes_sha.createKey();
			paes_sha.setkey(cle);
			keyExpansion = paes_sha.createKeyExpansion(PQ_AES.KEY_SIZE_256);
			imageCiphered = paes_sha.cipher(imageCSV, keyExpansion);
			break;
		case 3:
			cle = paes_sha3.createKey();
			paes_sha3.setkey(cle);
			keyExpansion = paes_sha3.createKeyExpansion(PQ_AES.KEY_SIZE_256);
			imageCiphered = paes_sha3.cipher(imageCSV, keyExpansion);
			break;
		case 4:
			cle = paes_shake.createKey();
			paes_shake.setkey(cle);
			keyExpansion = paes_shake.createKeyExpansion(PQ_AES.KEY_SIZE_256);
			imageCiphered = paes_shake.cipher(imageCSV, keyExpansion);
			break;
		case 5:
			cle = paes_keccak.createKey();
			paes_keccak.setkey(cle);
			keyExpansion = paes_keccak.createKeyExpansion(PQ_AES.KEY_SIZE_256);
			imageCiphered = paes_keccak.cipher(imageCSV, keyExpansion);
			break;
		default:
			System.out.println("Method unfound");
			System.exit(0);
		}
		// Writing the image into the output file:
		CSVProcessor.writeCSV(imageCiphered, out, "imageCiphered.csv");
		System.out.println("Ciphering done!!!!");
		System.out.println("Press any key to continue.....");
		sc.next();
		// Lecture de l'image chiffr�e apr�s la steganographie: Changer avec le chemin de nouveau
		
		String pathImCiphered = out+"imageCiphered.csv";
		byte[][] imToDecipher = CSVProcessor.readCSV(pathImCiphered, dim);
		byte[][] image = new byte[dim[0]][];
		
		switch(choixMethode) {
		case 1:
			image = aes.invCipher(imToDecipher, keyExpansion);
			break;
		case 2:
			image = paes_sha.cipher(imToDecipher, keyExpansion);
			break;
		case 3:
			image = paes_sha3.cipher(imToDecipher, keyExpansion);
			break;
		case 4:
			image = paes_shake.cipher(imToDecipher, keyExpansion);
			break;
		case 5:
			image = paes_keccak.cipher(imToDecipher, keyExpansion);
			break;
		default:
			System.out.println("Method unfound");
			System.exit(0);
		}
		CSVProcessor.writeCSV(image, out, "imreconstruct.csv");	
		// Les methodes de comparaisons des 2 image: image et 
	}

}
