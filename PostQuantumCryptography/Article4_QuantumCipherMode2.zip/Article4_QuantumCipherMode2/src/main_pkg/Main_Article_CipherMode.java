package main_pkg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main_Article_CipherMode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		AES aes = new AES(AES.KEY_SIZE_512);

		// multiplication boolean; 
		boolean[]a = new boolean[3];
		a[0] = true;
		a[1] = false;
		a[2] = true;
		boolean[]b = new boolean[5];
		b[0] = true;
		b[1] = false;
		b[2] = false;
		b[3] = true;
		b[4] = true;
		
		boolean []c = new boolean[4];
		c[0] = false;
		c[1] = true;
		c[2] = true;
		c[3] = true;
		
		aes.print_polynome(a);
		aes.print_polynome(b);
		aes.print_polynome(c);
		aes.finite_multiplication_galois(b, a, c);
		*/
		
/*		
 		AES aes = new AES(AES.KEY_SIZE_512);
 		//Testing Galois multiplication 
 		aes = new AES(AES.KEY_SIZE_512);
		byte[] a = new byte[2];
		a[0] = (byte) 141;
		a[1] = (byte) 111;

		aes.printByte(a, "a");
		byte[] b = new byte[1];
		b[0] = (byte) 123;
		
		byte[] c = new byte[2];;
		c[0] = (byte) 4;
		c[1] = (byte) 6;

		System.out.println("conversion :"+a[0]);
		aes.printByte(aes.toByteArray(aes.toBooleanArray(a)));
		
		byte[]res1 = aes.finite_multiplication_galois(a, b, c);
		aes.printByte(res1, "res1");
		
		byte[]res2 = aes.finite_multiplication_galois2(a, b, c);
		aes.printByte(res2, "res2");
*/
		
/*		
		AES aes = new AES(AES.KEY_SIZE_512);
 		//Testing Galois multiplication with large key
 		aes = new AES(AES.KEY_SIZE_512);
		byte[]a = aes.createKey();
		byte[]b = aes.createKey();
		byte[]c = aes.createKey();

		
		aes.printByte(aes.toByteArray(aes.toBooleanArray(a)));
		
		byte[]res1 = aes.finite_multiplication_galois(a, b, c);
		aes.printByte(res1, "res1");
		
		byte[]res2 = aes.finite_multiplication_galois2(a, b, c);
		aes.printByte(res2, "res2");
*/

		/*
		AES aes = new AES(AES.KEY_SIZE_512);
		//Testing set IV
		byte[] a = new byte[2];
		a[0] = (byte) 141;
		a[1] = (byte) 111;
		aes.setIV(a);
		aes.printByte(aes.iv, "IV");
		*/
		
/*		//testing polynome : 
		AES aes = new AES(AES.KEY_SIZE_128);
		aes.init_poly_irreductible();
		aes = new AES(AES.KEY_SIZE_256);
		aes.init_poly_irreductible();

		aes = new AES(AES.KEY_SIZE_512);
		aes.init_poly_irreductible();

		aes = new AES(AES.KEY_SIZE_1024);
		aes.init_poly_irreductible();
		
		aes = new AES(AES.KEY_SIZE_2048);
		aes.init_poly_irreductible();

		aes = new AES(AES.KEY_SIZE_4096);
		aes.init_poly_irreductible();
*/
		
	/*	 //cipher mode testing
		 try {
			AES aes = new AES(AES.KEY_SIZE_1024);
			byte[] bytesKey = aes.createKey();
			aes.setkey(bytesKey);
			//byte []iv = new byte[30];
			//iv[15] = 15;
			//iv[28] = 28;
			//aes.setIV(iv);
			//aes.setAAD("123");
			aes.cipher_ecb_file("src//main_pkg//video", "mp4");
			aes.invCipher_ecb_file("src//main_pkg//video_encECB", "mp4");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("finished");
		*/
		
		
		
		//cipher QUANTUM mode testing
/*		 try {
			 PQ_AES pqaes = new PQ_AES(PQ_AES.KEY_SIZE_1024);
			 byte[] bytesKey = pqaes.createKey();
			 pqaes.setkey(bytesKey);
			 pqaes.set_info("sha");

			//iv[15] = 15;
			//iv[28] = 28;
			//aes.setIV(iv);
			//aes.setAAD("123");
			pqaes.cipher_ecb_file("src//main_pkg//test", "txt");
			pqaes.invCipher_ecb_file("src//main_pkg//test_encECB", "txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	*/
		
		 try {
			 PQ_AES pqaes = new PQ_AES(PQ_AES.KEY_SIZE_4096);
			 byte[] bytesKey = pqaes.createKey();
			 System.out.println("key : "+bytesKey.length);
			 pqaes.printByte(bytesKey);
			 pqaes.setkey(bytesKey);
			 pqaes.set_info("sha"); // for pqaes only

			//iv[15] = 15;
			//iv[28] = 28;
			//aes.setIV(iv);
			//aes.setAAD("123");
			pqaes.cipher_gcm_cbc_file("src//main_pkg//test", "txt");
			pqaes.invCipher_gcm_cbc_file("src//main_pkg//test_encGCMCBC", "txt");
			System.out.println("here");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
	}

	
}
