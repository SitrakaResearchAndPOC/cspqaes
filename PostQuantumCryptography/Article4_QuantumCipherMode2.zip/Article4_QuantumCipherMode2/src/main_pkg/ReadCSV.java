package main_pkg;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;




public class ReadCSV {
private  static String params ="params"+File.separator;
private  static String entree ="entree"+File.separator;
private  static String sortie ="sortie"+File.separator;

private static AES aes = new AES(AES.KEY_SIZE_256);
private static byte[] cle = aes.createKey();
private static int[] wordsKeyExpansion = aes.createKeyExpansion(cle);
	
	public static int[] dimension() throws IOException {
		File fichier = new File(params+"dimension.bin");
		DataInputStream in = new DataInputStream(new FileInputStream(fichier)); 
		int ligne   = in.readInt();
		int colonne = in.readInt();
		in.close();
		return new int[] {ligne,colonne};
	}
	// lire le fichier CSV:
	public static byte[] str2ByteArray(String chaine) {
		String[] tmp_str = chaine.split(",");
		byte[] res = new byte[tmp_str.length];
		for(int i = 0; i < tmp_str.length; i++) {
			res[i]=Byte.parseByte(tmp_str[i]);
		}
		return res;
	}
	public static void display(byte[] tableau,int numbers) {
		int i = 0;
		for(i=0;i<numbers && i<tableau.length;i++) {
			System.out.printf("%5d",tableau[i]);
		}
		System.out.println("");
	}
	
	public static void display(byte[] tableau) {
		display(tableau,tableau.length);
	}
	
	public static void displayMatrice(byte[][] matrice,int ligne,int colonne) {
		for(int i= 0;i<ligne;i++) {
			display(matrice[i], colonne);
		}
	}
	public static void displayMatrice(byte[][] matrice) {
		int ligne =matrice.length;
		int colonne = matrice[0].length;
		displayMatrice(matrice,ligne, colonne);
	}
	public static byte[][] readImage(File monFichierCSV,int[] dim) throws IOException{
		byte[][] image = new byte[dim[0]][];
		Scanner sc = new Scanner(monFichierCSV);
		int ligne =0;
		while(sc.hasNext()) {
			String chaine = sc.next();
			byte[] row = str2ByteArray(chaine);
			image[ligne]=row;
			ligne++;
			
		}
		sc.close();
		return image;
		
	}
	public static byte[][] encryptPlainImageAES(byte[][] image) {
		
		byte[][] imageEncrypted = new byte[image.length][];
		int i = 0;
		for(byte [] tmp:image) {
			byte[] tmpEncrypted = aes.cipher(tmp, wordsKeyExpansion);
			imageEncrypted[i] = tmpEncrypted;
			i++;
		}
		
		return imageEncrypted;
	}
	
public static byte[][] decryptPlainImageAES(byte[][] imageEncrypted) {
		
		byte[][] image = new byte[imageEncrypted.length][];
		int i = 0;
		for(byte [] tmpEncrypted:imageEncrypted) {
			byte[] tmp = aes.invCipher(tmpEncrypted, wordsKeyExpansion);
			image[i] = tmp;
			i++;
		}
		return image;
	}
private static void writeCSV(byte[][] image,File output_path,String filename) {
	File fullPath = new File(output_path+File.pathSeparator+filename);
	try(PrintWriter csvout = new PrintWriter(fullPath)) {
		for (byte[] ligne:image) {
			for(int i = 0;i < ligne.length;i++) {
				csvout.print(ligne[i]+(i<(ligne.length-1) ? "," : ""));
				
			}
			csvout.println("");
		}
	} catch (Exception e) {
		System.err.println(e.getMessage());
	}
}
	public static void main(String[] args) throws IOException {
//		try(
//				DataOutputStream out = new DataOutputStream(new FileOutputStream(new File(params+"dimension.bin")));
//		){
//			int ligne = 64;
//			int colonne = 256;
//			out.writeInt(ligne);
//			out.writeInt(colonne);
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
		byte[][] image = new byte[][] {
			{1,2,3},
			{1,2,3},
			{1,2,3}
		};
		
		byte[][] imageEcrypted = encryptPlainImageAES(image);
		String imageEncryptedCSV = "imageEncryptedOutCSV.csv";
		// writeCSV(imageEcrypted, imageEncryptedCSV);
		
		byte[][] imagedecrypted = decryptPlainImageAES(imageEcrypted);
		String imageDecryptedCSV = "imageDecryptedOutCSV.csv";
		// writeCSV(imagedecrypted, imageDecryptedCSV);
		
	}
}
