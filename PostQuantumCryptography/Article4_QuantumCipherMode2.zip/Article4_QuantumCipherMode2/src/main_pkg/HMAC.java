package main_pkg;

import com.ryan.core.Digests;

import uk.org.bobulous.java.crypto.keccak.FIPS202;
/*create by sitraka  29/12/2022*/
public class HMAC {

	String info;
	int length_hash;
	public HMAC(String info, int length_hash) {
		// TODO Auto-generated constructor stub
		this.info = info;
		this.length_hash = length_hash;
	}
	
	   public byte[] createKey() {
	        byte key[] = new byte[length_hash/8];
	        java.util.Random rndGen = new java.util.Random();
	        rndGen.nextBytes(key);
	        return key;
	    }


	/*inspired on java code stackoverflow*/
	   public static String toHexString2(byte[] bytes) {
	        char[] hexArray = "0123456789ABCDEF".toCharArray();
	        char[] hexChars = new char[bytes.length * 2];
	        for (int j = 0; j < bytes.length; j++) {
	            int v = bytes[j] & 0xFF;
	            hexChars[j * 2] = hexArray[v >>> 4];
	            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
	        }
	        return new String(hexChars);
	    }
	    
	    
	    public static String toHexString(byte[] byteArray)
	    {
	        String hex = "";
	  
	        // Iterating through each byte in the array
	        for (byte i : byteArray) {
	            hex += String.format("%02X", i);
	        }
	        //System.out.print(hex);
	        return hex;
	    }
	    /*inspired at : https://www.geeksforgeeks.org/java-program-to-convert-hex-string-to-byte-array/*/
	    public byte[] toStringHex(String key) {
	    	 int len = key.length();
	         byte[] ans = new byte[len / 2];
	        
	         for (int i = 0; i < len; i += 2) {
	              // using left shift operator on every character
	             ans[i / 2] = (byte) ((Character.digit(key.charAt(i), 16) << 4)
	                     + Character.digit(key.charAt(i+1), 16));
	         }
	         
	         System.out.print("Byte Array : ");
	           
	          for(int i=0;i<ans.length;i++){
	             System.out.print(ans[i]+" ");
	        }
	         return ans;
	    	
	    }
	    
	    
	    /*xor array bytes : https://programming-idioms.org/idiom/238/xor-byte-arrays/5801/java*/
	byte [] bytes_arrays_xor(byte []input1, byte [] input2){
		byte[] result = new byte[input1.length];
		if(input1.length != input2.length) {
			return null;
		}else {
			for (int i = 0; i < input1.length; i++) {
			  result[i] = (byte) (input1[i] ^ input2[i]);
			}
			
		}
		return result;
	}
	
	byte [] bytes_arrays_concat(byte[] input1, byte[] input2) {
	    int len1 = input1.length;
	    int len2 = input2.length;
	    
	    byte[] res = new byte[len1 + len2];
		for(int i = 0; i <len1; i++) {
			res[i] = input1[i];
		}
		for(int i = 0; i < len2; i++) {
			res[i+len1] = input2[i];
		}
		return res;
	}

	
	byte [] do_final(byte[] msg, byte[] ikm) {
		byte ipad[] = null;
		byte opad[] = null;
		byte []key1 = null;
		byte []key2 = null;
		if(ikm.length < length_hash/8) {
			System.out.println("Error key length");
			return null;
		}
		else if(ikm.length == length_hash/8) {
			/*intialize ipad by 0x36363636 -->  and opad by 0x5c5c5c5*/
			ipad = new byte [(length_hash/8)];
			for(int i = 0; i < ipad.length; i++) {
				ipad[i] = 54;//16*3+6
			}
//			System.out.println("ipad : "+toHexString(ipad));
			
			opad = new byte [(length_hash/8)];
			for(int i = 0; i < opad.length; i++) {
				opad[i] = 92; //16*5+c
			}
//			System.out.println("opad : "+toHexString(opad));
			key1 = bytes_arrays_xor(ipad, ikm);
			key2 = bytes_arrays_xor(opad, ikm);
			
		
		//	System.out.println("xor opad : "+toHexString(key2));
		//	System.out.println("xor ipad : "+toHexString(key1));

		}else {
			/*intialize ipad by 0x36363636 -->  and opad by 0x5c5c5c5*/
			ipad = new byte [ikm.length];
			for(int i = 0; i < ipad.length; i++) {
				ipad[i] = 54;//16*3+6
			}
//			System.out.println("ipad : "+toHexString(ipad));
			
			opad = new byte [ikm.length];
			for(int i = 0; i < opad.length; i++) {
				opad[i] = 92; //16*5+c
			}
//			System.out.println("opad : "+toHexString(opad));
			key1 = bytes_arrays_xor(ipad, ikm);
			key2 = bytes_arrays_xor(opad, ikm);
			
		
		//	System.out.println("xor opad : "+toHexString(key2));
		//	System.out.println("xor ipad : "+toHexString(key1));
			
			
		}
		
		/*SELELCTING ALGORITHM*/
		if((this.info =="sha")||(this.info =="SHA")) {
			if(this.length_hash == 256) {
				byte []msg1 = bytes_arrays_concat(key1, msg);
				byte []hmac_res1 = Digests.sha256().digest(msg1, 0, msg1.length);
				byte []msg2 = bytes_arrays_concat(key2, hmac_res1);	
				byte []hmac_res = Digests.sha256().digest(msg2,0, msg2.length);
				//System.out.println("hmac result : "+toHexString(hmac_res));
				return hmac_res;
			}else if(this.length_hash == 512) {
				byte []msg1 = bytes_arrays_concat(key1, msg);
				byte []hmac_res1 = Digests.sha512().digest(msg1, 0, msg1.length);
				byte []msg2 = bytes_arrays_concat(key2, hmac_res1);	
				byte []hmac_res = Digests.sha512().digest(msg2,0, msg2.length);
//				System.out.println("hmac result : "+toHexString(hmac_res));
				return hmac_res;
				
			}else {
				return null;
			}
		} else if((this.info =="keccak")||(this.info =="KECCAK")||(this.info =="Keccak")) {
			if(this.length_hash == 256) {
				byte []msg1 = bytes_arrays_concat(key1, msg);
				byte []hmac_res1 = Digests.keccak256().digest(msg1, 0, msg1.length);
				byte []msg2 = bytes_arrays_concat(key2, hmac_res1);	
				byte []hmac_res = Digests.keccak256().digest(msg2,0, msg2.length);
				//System.out.println("hmac result : "+toHexString(hmac_res));
				return hmac_res;
			}else if(this.length_hash == 512) {
				byte []msg1 = bytes_arrays_concat(key1, msg);
				byte []hmac_res1 = Digests.keccak512().digest(msg1, 0, msg1.length);
				byte []msg2 = bytes_arrays_concat(key2, hmac_res1);	
				byte []hmac_res = Digests.keccak512().digest(msg2,0, msg2.length);
				//System.out.println("hmac result : "+toHexString(hmac_res));
				return hmac_res;
				
			}else {
				return null;
			}
		} else 	if((this.info =="sha3")||(this.info =="SHA3")) {
			if(this.length_hash == 256) {
				byte []msg1 = bytes_arrays_concat(key1, msg);
				byte []hmac_res1 = FIPS202.HashFunction.SHA3_256.apply(msg1);
				byte []msg2 = bytes_arrays_concat(key2, hmac_res1);	
				byte []hmac_res = FIPS202.HashFunction.SHA3_256.apply(msg2);;
				//System.out.println("hmac result : "+toHexString(hmac_res));
				return hmac_res;
			}else if(this.length_hash == 512) {
				byte []msg1 = bytes_arrays_concat(key1, msg);
				byte []hmac_res1 = FIPS202.HashFunction.SHA3_512.apply(msg1);;
				byte []msg2 = bytes_arrays_concat(key2, hmac_res1);	
				byte []hmac_res = FIPS202.HashFunction.SHA3_512.apply(msg2);;
//				System.out.println("hmac result : "+toHexString(hmac_res));
				return hmac_res;
				
			}else {
				return null;
			}
		} else 	if((this.info =="shake")||(this.info =="SHAKE")||(this.info =="Shake")) {
				byte []msg1 = bytes_arrays_concat(key1, msg);
				byte []hmac_res1 = FIPS202.ExtendableOutputFunction.SHAKE256.withOutputLength(length_hash).apply(msg1);
				byte []msg2 = bytes_arrays_concat(key2, hmac_res1);	
				byte []hmac_res = FIPS202.ExtendableOutputFunction.SHAKE256.withOutputLength(length_hash).apply(msg2);
				//System.out.println("hmac result : "+toHexString(hmac_res));
				return hmac_res;
		} else 	if((this.info =="rawshake")||(this.info =="RAWSHAKE")||(this.info =="RawSHAKE")||(this.info =="RawShake")) {
			byte []msg1 = bytes_arrays_concat(key1, msg);
			byte []hmac_res1 = FIPS202.ExtendableOutputFunction.RawSHAKE256.withOutputLength(length_hash).apply(msg1);
			byte []msg2 = bytes_arrays_concat(key2, hmac_res1);	
			byte []hmac_res = FIPS202.ExtendableOutputFunction.RawSHAKE256.withOutputLength(length_hash).apply(msg2);
			//System.out.println("hmac result : "+toHexString(hmac_res));
			return hmac_res;
		} 
		return null;
	}
}
