package main_pkg;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class Parametres {
	static String params ="params"+File.separator;
	public static int[] dimension() throws IOException {
		File fichier = new File(params+"dimension.bin");
		DataInputStream in = new DataInputStream(new FileInputStream(fichier)); 
		int ligne   = in.readInt();
		int colonne = in.readInt();
		in.close();
		return new int[] {ligne,colonne};
	}
}
