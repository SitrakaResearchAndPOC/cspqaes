package main_pkg;
/*code by sitraka 09/01/2023*/

public class Main_article {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		String[] hash_function = {"sha", "keccak",  "sha3", "shake", "rawshake"};
		//String[] hash_function = {"sha"};
		int [] length_hash_function = {256, 512, 1024, 2048, 4096};
		//int [] length_hash_function = {4096};
		
		/* all extract value for each time word expansion */
		long[][] pqaes_time_word_expansion_final = new long[hash_function.length][length_hash_function.length];
		long[][] aes_time_word_expansion_final = new long[hash_function.length][length_hash_function.length];
		long[][] pqaes_time_padding_pkcs_final = new long[hash_function.length][length_hash_function.length];
		long[][] aes_time_padding_pkcs_final = new long[hash_function.length][length_hash_function.length];		
		long[][] pqaes_time_padding_pkcs_inv_final = new long[hash_function.length][length_hash_function.length];
		long[][] aes_time_padding_pkcs_inv_final = new long[hash_function.length][length_hash_function.length];
		long[][] pqaes_time_padding_ansi_9323_final = new long[hash_function.length][length_hash_function.length];
		long[][] aes_time_padding_ansi_9323_final = new long[hash_function.length][length_hash_function.length];
		long[][] pqaes_time_padding_ansi_9323_inv_final = new long[hash_function.length][length_hash_function.length];
		long[][] aes_time_padding_ansi_9323_inv_final = new long[hash_function.length][length_hash_function.length];
		long[][] pqaes_time_padding_wc3_final = new long[hash_function.length][length_hash_function.length];
		long[][] aes_time_padding_wc3_final = new long[hash_function.length][length_hash_function.length];
		long[][] pqaes_time_padding_wc3_inv_final = new long[hash_function.length][length_hash_function.length];
		long[][] aes_time_padding_wc3_inv_final = new long[hash_function.length][length_hash_function.length];
		long[][] pqaes_time_padding_one_zero_final = new long[hash_function.length][length_hash_function.length];
		long[][] aes_time_padding_one_zero_final = new long[hash_function.length][length_hash_function.length];
		long[][] pqaes_time_padding_one_zero_inv_final = new long[hash_function.length][length_hash_function.length];
		long[][] aes_time_padding_one_zero_inv_final = new long[hash_function.length][length_hash_function.length];
		long[][] pqaes_time_ciphering_final = new long[hash_function.length][length_hash_function.length];
		long[][] aes_time_ciphering_final = new long[hash_function.length][length_hash_function.length];
		long[][] pqaes_time_ciphering_inv_final = new long[hash_function.length][length_hash_function.length];
		long[][] aes_time_ciphering_inv_final = new long[hash_function.length][length_hash_function.length];
		ExtractIndicator extr = null;
		
		for(int h = 0; h < hash_function.length; h++) {
			PQ_AES pqaes = null;
			AES aes = null;
			byte[] bytesKey = null;
			for(int l = 0; l < length_hash_function.length; l++) {
				pqaes = new PQ_AES(length_hash_function[l]);
				aes = new AES(length_hash_function[l]);
				bytesKey = pqaes.createKey(); // same for pqaes and aes
				
				Indicator ind = new Indicator(hash_function, length_hash_function);
				ind.setAes(aes);
				ind.setPqaes(pqaes);
				ind.setBytesKey(bytesKey);
				extr = ind.treatement(h, l);
				
				// GETTING ALL PARAMETES FOR PQAES
				if(extr.pqaes_time_word_expansion_cmpt != 0) {
					pqaes_time_word_expansion_final[h][l] = extr.pqaes_time_word_expansion/extr.pqaes_time_word_expansion_cmpt;					
				}else {
					pqaes_time_word_expansion_final[h][l] = -1;
				}
				
				if(extr.pqaes_time_padding_pkcs_cmpt != 0) {
					pqaes_time_padding_pkcs_final[h][l] = extr.pqaes_time_padding_pkcs/extr.pqaes_time_padding_pkcs_cmpt;					
				}else {
					pqaes_time_padding_pkcs_final[h][l] = -1;
				}
				
				if(extr.pqaes_time_padding_pkcs_inv_cmpt != 0) {
					pqaes_time_padding_pkcs_inv_final[h][l] = extr.pqaes_time_padding_pkcs_inv/extr.pqaes_time_padding_pkcs_inv_cmpt;
					
				}else {
					pqaes_time_padding_pkcs_inv_final[h][l] = -1;
				}
				
				if(extr.pqaes_time_padding_ansi_9323_cmpt != 0) {
					pqaes_time_padding_ansi_9323_final[h][l] = extr.pqaes_time_padding_ansi_9323/extr.pqaes_time_padding_ansi_9323_cmpt;					
					
				}else {
					pqaes_time_padding_ansi_9323_final[h][l] = -1;
				}

				if(extr.pqaes_time_padding_ansi_9323_inv_cmpt != 0) {
					pqaes_time_padding_ansi_9323_inv_final[h][l] = extr.pqaes_time_padding_ansi_9323_inv/extr.pqaes_time_padding_ansi_9323_inv_cmpt;					
				}else {
					pqaes_time_padding_ansi_9323_inv_final[h][l] = -1;					
				}
				
				if(extr.pqaes_time_padding_wc3_cmpt != 0) {
					pqaes_time_padding_wc3_final[h][l] = extr.pqaes_time_padding_wc3/extr.pqaes_time_padding_wc3_cmpt;										
				}else {
					pqaes_time_padding_wc3_final[h][l] = -1;
				}
				
				if(extr.pqaes_time_padding_wc3_inv_cmpt != 0) {
					pqaes_time_padding_wc3_inv_final[h][l] = extr.pqaes_time_padding_wc3_inv/extr.pqaes_time_padding_wc3_inv_cmpt;					
				}else {
					pqaes_time_padding_wc3_inv_final[h][l] = -1;
				}
				
				if(extr.pqaes_time_padding_one_zero_cmpt != 0) {
					pqaes_time_padding_one_zero_final[h][l] = extr.pqaes_time_padding_one_zero/extr.pqaes_time_padding_one_zero_cmpt;										
				}else {
					pqaes_time_padding_one_zero_final[h][l] = -1;										
				}
				
				if(extr.pqaes_time_padding_one_zero_inv_cmpt != 0) {
					pqaes_time_padding_one_zero_inv_final[h][l] = extr.pqaes_time_padding_one_zero_inv/extr.pqaes_time_padding_one_zero_inv_cmpt;										
				}else {
					pqaes_time_padding_one_zero_inv_final[h][l] = -1;					
				}
				
				if(extr.pqaes_time_ciphering_cmpt != 0) {
					pqaes_time_ciphering_final[h][l] = extr.pqaes_time_ciphering/extr.pqaes_time_ciphering_cmpt;										
				}else {
					pqaes_time_ciphering_final[h][l] = -1;					
				}
				
				if(extr.pqaes_time_ciphering_inv_cmpt != 0) {
					pqaes_time_ciphering_inv_final[h][l] = extr.pqaes_time_ciphering_inv/extr.pqaes_time_ciphering_inv_cmpt;										
				}else {
					pqaes_time_ciphering_inv_final[h][l] = -1;										
				}
 
				
				// GETTING ALL PARAMETES FOR AES
				if(extr.aes_time_word_expansion_cmpt != 0) {
					aes_time_word_expansion_final[h][l] = extr.aes_time_word_expansion/extr.aes_time_word_expansion_cmpt;					
				}else {
					aes_time_word_expansion_final[h][l] = -1;
				}
				
				if(extr.aes_time_padding_pkcs_cmpt != 0) {
					aes_time_padding_pkcs_final[h][l] = extr.aes_time_padding_pkcs/extr.aes_time_padding_pkcs_cmpt;					
				}else {
					aes_time_padding_pkcs_final[h][l] = -1;
				}
				
				if(extr.aes_time_padding_pkcs_inv_cmpt != 0) {
					aes_time_padding_pkcs_inv_final[h][l] = extr.aes_time_padding_pkcs_inv/extr.aes_time_padding_pkcs_inv_cmpt;
				}else {
					aes_time_padding_pkcs_inv_final[h][l] = -1;
				}
				
				if(extr.aes_time_padding_ansi_9323_cmpt != 0) {
					aes_time_padding_ansi_9323_final[h][l] = extr.aes_time_padding_ansi_9323/extr.aes_time_padding_ansi_9323_cmpt;					
				}else {
					aes_time_padding_ansi_9323_final[h][l] = -1;
				}

				if(extr.aes_time_padding_ansi_9323_inv_cmpt != 0) {
					aes_time_padding_ansi_9323_inv_final[h][l] = extr.aes_time_padding_ansi_9323_inv/extr.aes_time_padding_ansi_9323_inv_cmpt;					
				}else {
					aes_time_padding_ansi_9323_inv_final[h][l] = -1;					
				}
				
				if(extr.aes_time_padding_wc3_cmpt != 0) {
					aes_time_padding_wc3_final[h][l] = extr.aes_time_padding_wc3/extr.aes_time_padding_wc3_cmpt;										
				}else {
					aes_time_padding_wc3_final[h][l] = -1;
				}
				
				if(extr.aes_time_padding_wc3_inv_cmpt != 0) {
					aes_time_padding_wc3_inv_final[h][l] = extr.aes_time_padding_wc3_inv/extr.aes_time_padding_wc3_inv_cmpt;					
				}else {
					aes_time_padding_wc3_inv_final[h][l] = -1;
				}
				
				if(extr.aes_time_padding_one_zero_cmpt != 0) {
					aes_time_padding_one_zero_final[h][l] = extr.aes_time_padding_one_zero/extr.aes_time_padding_one_zero_cmpt;										
				}else {
					aes_time_padding_one_zero_final[h][l] = -1;										
				}
				
				if(extr.aes_time_padding_one_zero_inv_cmpt != 0) {
					aes_time_padding_one_zero_inv_final[h][l] = extr.aes_time_padding_one_zero_inv/extr.aes_time_padding_one_zero_inv_cmpt;										
				}else {
					aes_time_padding_one_zero_inv_final[h][l] = -1;					
				}
				
				if(extr.aes_time_ciphering_cmpt != 0) {
					aes_time_ciphering_final[h][l] = extr.aes_time_ciphering/extr.aes_time_ciphering_cmpt;										
				}else {
					aes_time_ciphering_final[h][l] = -1;					
				}
				
				if(extr.aes_time_ciphering_inv_cmpt != 0) {
					aes_time_ciphering_inv_final[h][l] = extr.aes_time_ciphering_inv/extr.aes_time_ciphering_inv_cmpt;										
				}else {
					aes_time_ciphering_inv_final[h][l] = -1;										
				}				
				
			}
		}

		/*EXTRACT ALL TIME COMPARAISON*/
		extr.to_csv(pqaes_time_word_expansion_final, "pqaes_time_word_expansion");
		extr.to_csv(pqaes_time_padding_pkcs_final, "pqaes_time_padding_pkcs");
			
	
	}

}
