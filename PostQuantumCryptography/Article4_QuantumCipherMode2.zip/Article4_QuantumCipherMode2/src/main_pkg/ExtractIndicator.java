package main_pkg;

import java.io.File;
import java.io.FileWriter;

public class ExtractIndicator {
	/*PARAMETER PQAES*/
	public long pqaes_time_word_expansion = 0;
	public long pqaes_time_word_expansion_cmpt = 0;

	public long pqaes_time_padding_pkcs = 0;
	public long pqaes_time_padding_pkcs_cmpt = 0;
	
	
	public long pqaes_time_padding_pkcs_inv = 0;
	public long pqaes_time_padding_pkcs_inv_cmpt = 0;


	public long pqaes_time_padding_ansi_9323 = 0;
	public long pqaes_time_padding_ansi_9323_cmpt = 0;

	public long pqaes_time_padding_ansi_9323_inv = 0;
	public long pqaes_time_padding_ansi_9323_inv_cmpt = 0;
	
	
	public long pqaes_time_padding_wc3 = 0;
	public long pqaes_time_padding_wc3_cmpt = 0;

	public long pqaes_time_padding_wc3_inv = 0;
	public long pqaes_time_padding_wc3_inv_cmpt = 0;

	
	public long pqaes_time_padding_one_zero = 0;
	public long pqaes_time_padding_one_zero_cmpt = 0;

	public long pqaes_time_padding_one_zero_inv = 0;
	public long pqaes_time_padding_one_zero_inv_cmpt = 0;

	
	public long pqaes_time_ciphering = 0;
	public long pqaes_time_ciphering_cmpt = 0;
	
	public long pqaes_time_ciphering_inv = 0;
	public long pqaes_time_ciphering_inv_cmpt = 0;

	/*PARAMETER AES*/
	public long aes_time_word_expansion = 0;
	public long aes_time_word_expansion_cmpt = 0;

	public long aes_time_padding_pkcs = 0;
	public long aes_time_padding_pkcs_cmpt = 0;
	
	
	public long aes_time_padding_pkcs_inv = 0;
	public long aes_time_padding_pkcs_inv_cmpt = 0;


	public long aes_time_padding_ansi_9323 = 0;
	public long aes_time_padding_ansi_9323_cmpt = 0;

	public long aes_time_padding_ansi_9323_inv = 0;
	public long aes_time_padding_ansi_9323_inv_cmpt = 0;
	
	
	public long aes_time_padding_wc3 = 0;
	public long aes_time_padding_wc3_cmpt = 0;

	public long aes_time_padding_wc3_inv = 0;
	public long aes_time_padding_wc3_inv_cmpt = 0;

	
	public long aes_time_padding_one_zero = 0;
	public long aes_time_padding_one_zero_cmpt = 0;

	public long aes_time_padding_one_zero_inv = 0;
	public long aes_time_padding_one_zero_inv_cmpt = 0;

	
	public long aes_time_ciphering = 0;
	public long aes_time_ciphering_cmpt = 0;
	
	public long aes_time_ciphering_inv = 0;
	public long aes_time_ciphering_inv_cmpt = 0;
	String[] hash_function;
	int [] length_hash_function;
	
	
	/*For the CSV Writer*/
	/*inspired on : https://waytolearnx.com/2020/03/exporter-des-donnees-dans-un-fichier-csv-en-java.html*/
	  //D�limiteurs qui doivent �tre dans le fichier CSV
	    @SuppressWarnings("unused")
		private static final String DELIMITER = ",";
	    @SuppressWarnings("unused")
		private static final String SEPARATOR = "\n";

	public ExtractIndicator(String[] hash_function, int [] length_hash_function) {
		// TODO Auto-generated constructor stub
		this.hash_function = hash_function;
		this.length_hash_function = length_hash_function;
	}

	public void to_csv(long output[][], String namefile) {
    	for(int h = 0; h <hash_function.length; h++) {
    		FileWriter file = null;
    	    try
    	      {
    	    	  /*
    	    	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
    	    	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
    	    	  * */
    	    	File yourFile = new File("src/"+namefile+"_"+hash_function[h]+".csv");
    	    	yourFile.createNewFile(); 
    	    	file = new FileWriter("src/"+namefile+"_"+hash_function[h]+".csv");
    	    	for(int l = 0; l < this.length_hash_function.length-1; l++) {
    				file.append(String.valueOf(output[h][l]));
    		        file.append(DELIMITER);    	    	
    		    }
    	        file.append(String.valueOf(output[h][this.length_hash_function.length-1]));        

    	        file.close();
    	      }
    	      catch(Exception e)
    	      {
    	        e.printStackTrace();
    	      }

    	}
		
	      	
	}
}
