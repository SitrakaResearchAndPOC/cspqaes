package main_pkg;

public class MatriceTools {
	public static void displayMatrice(byte[][] matrice,int ligne,int colonne) {
		ligne   = (ligne   < matrice.length) ?ligne   : matrice.length;
		colonne = (colonne < matrice[0].length) ?colonne : matrice[0].length;
		
		for(int i= 0;i<ligne;i++) {
			display(matrice[i], colonne);
		}
	}
	private static void display(byte[] tableau,int numbers) {
		int i = 0;
		for(i=0;i<numbers && i<tableau.length;i++) {
			System.out.printf("%5d",tableau[i]);
		}
		System.out.println("");
	}
	
}
