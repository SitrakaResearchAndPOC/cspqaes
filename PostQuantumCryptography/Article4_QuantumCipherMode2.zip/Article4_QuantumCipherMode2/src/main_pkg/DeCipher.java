package main_pkg;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class DeCipher {
	public static byte[] readByte(File byteFile) {
		byte[] byteTab = null;
		try(DataInputStream byteDataRead = new DataInputStream(new FileInputStream(byteFile))){
			byteTab = byteDataRead.readAllBytes();
			return byteTab;
		}catch(Exception e){
			System.out.println("Unable to read the byte file!");
			return null;
		}
	}
	public static int[] readInt(File intFile) {
		int[] intTab = null;
		try(DataInputStream intDataRead = new DataInputStream(new FileInputStream(intFile))){
			ArrayList<Integer> intList = new ArrayList<Integer>();
			while(intDataRead.available()>0) {
				intList.add(intDataRead.readInt());
			}
			intTab = new int[intList.size()];
			for(int i = 0;i<intList.size();i++) {
				intTab[i] = intList.get(i);
			}
			return intTab;
		}catch(Exception e){
			System.out.println("Unable to read the byte file!");
			return intTab;
		}
	}
	
	public static void main(String[] args) throws Exception {
		long start = System.currentTimeMillis();
		if(args.length < 4) {
			System.out.println("Program successfully compiled!");
			System.exit(0);;
		}
		String type_chiffrement  = args[0];
		String parameters_path   = args[1];
		String imageCipheredPath = args[2];
		int ligne				 = Integer.parseInt(args[3]);
		int colonne				 = Integer.parseInt(args[4]);
		
		String clePath           = parameters_path + File.separator + "cle"+File.separator + "cle.dat";
		String keyExpansionPath  = parameters_path + File.separator + "keyExpansion" + File.separator  + "keyExpansion.dat";
		String finalOutputPath   = parameters_path + File.separator + "finalOutput";
		
		// Image Ciphered
		byte[][] imageCiphered = CSVProcessor.readCSV(imageCipheredPath, new int[] {ligne,colonne});
		// cle
		byte[] cle             = readByte(new File(clePath));
		// KeyExpansion
		int[] keyExpansion     = readInt(new File(keyExpansionPath));
		// image intiale:
		byte[][] image = null;
		
		
		// affichage
		System.out.print("Cle: ");
		for(byte b: cle) {
			System.out.print(b +" ");
		}
		System.out.print("\nKey Expansion: ");
		for(int b: keyExpansion) {
			System.out.print(b +" ");
		}
		
		// D�chiffrement:
		System.out.println("milance radecipher");
		System.out.println("image entrant");
		ReadCSV.displayMatrice(imageCiphered, 10, 10);
		
		switch(type_chiffrement) {
			case "AES"       -> {
				
			AES_image aes = new AES_image(AES.KEY_SIZE_256);
				System.out.println("mandalo eto @ aes");
				aes.setkey(cle);
				keyExpansion = aes.createKeyExpansion(cle);
				image = aes.invCipher(imageCiphered, keyExpansion);
				
			}
			case "PQAES_SHA" ->{
				PQAES_SHA pqaes_sha = new PQAES_SHA(PQ_AES.KEY_SIZE_256);
				pqaes_sha.setkey(cle);
				image       = pqaes_sha.invCipher(imageCiphered, keyExpansion);
			}
			case "PQAES_SHA3" ->{
				PQAES_SHA paes_sha3 = new PQAES_SHA(PQ_AES.KEY_SIZE_256);
				paes_sha3.setkey(cle);
				image       = paes_sha3.invCipher(imageCiphered, keyExpansion);
			}
			case "PQAES_KECCAK"->{
				PQAES_KECCAK paes_keccak = new PQAES_KECCAK(PQ_AES.KEY_SIZE_256);
				paes_keccak.setkey(cle);
				image            = paes_keccak.invCipher(imageCiphered, keyExpansion);
			}
			case "PQAES_SHAKE" ->{
				PQAES_SHAKE paes_shake = new PQAES_SHAKE(PQ_AES.KEY_SIZE_256);
				paes_shake.setkey(cle);
				image          = paes_shake.invCipher(imageCiphered, keyExpansion);
			}
		}
		
		
		System.out.println("image recuperer");
		ReadCSV.displayMatrice(image, 10, 10);

		System.out.println("Deciphering done!");
		// Ecriture de l'image final
		// 1- Cr�ation du dossier s'il n'existe pas encore:
		File finalOutput = new File(finalOutputPath);
		if(!finalOutput.exists()) {
			finalOutput.mkdirs();
		}
		
		// 2- Ecrire dans le dossier final
		String filename = "finalOutput.csv";
		CSVProcessor.writeCSV(image, finalOutput.getAbsolutePath(), filename);
		System.out.println("Operation done!");
	}
}
