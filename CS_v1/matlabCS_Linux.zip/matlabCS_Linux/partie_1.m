%% function simulation_cs()
%% INPUT VARIABLES FOR JAVA:
%% Ciphering parameters:
binPath     = '/root/eclipse-workspace/Article4_QuantumCipherMode2/bin';
cipherClass = 'main_pkg.Cipher';
cipherModes = {'AES','PQAES_SHA','PQAES_SHA3','PQAES_KECCAK','PQAES_SHAKE'};
cipherMode  = cipherModes{1};
compressed_image_path = '/usr/local/MATLAB/R2018b/bin/SimulCS/input_java';
ciphered_image_path   = '/usr/local/MATLAB/R2018b/bin/SimulCS/output_java';


%% 1- GET THE IMAGE
imagesource     = double(imread('imageSource.bmp'));
image           = (imagesource);
[ligne,colonne] = size(image); 
%% 2- GET THE INITIAL PARAMETERS:
% S = [x0';y0';r;z0']
S = abs(rand(4,1));

% Compressive ratio:
compressive_ratio = .25;
ligne_cr          = compressive_ratio * ligne;

% Sampling distance:
sampling_distance = 20;

% 256 Bits = 32 blocks of 8 bits:
P = generateBitBlocks(32,8);

%% GENERATION DES PARAMETRES Q:
Q   = initialParameters(P,S);
% Inutile --> Pour le zigzag:
x_0 = delimit(Q(1,:),colonne,1);
y_0 = delimit(Q(2,:),ligne,1) ;

g_0   = Q(3,:);
r_max = .6;
r_min =.3;
r     = Q(4,:);

%% GENERATION DE LA MATRICE SENSING
sensing_matrix = sensingMatrix(ligne_cr,colonne,[sampling_distance;g_0;r]);
%% sensing_matrix =orth(sensing_matrix);

%% WAVELET TRANSFORM
[C, S] = wavedec2(image,2,'haar');
CA = C(1:S(1)*S(2));
C(1:S(1)*S(2))=1e-9;
image = reshape(C,ligne,colonne);

%% ZIGZAG
image =zigzag(image,x_0,y_0);

%% COMPRESSIVE SENSING(encore à dvep) 
image = compression(sensing_matrix,image);
 
%% QUANTIFICATION
max_im = max(max(image));
min_im = min(min(image));
 
%% QUANTIFICATION + TRANSFORMATION EN BYTE SIGNE [-128, 127]
% QUANTIFICATION DE L'IMAGE
image = quantification(image,max_im,min_im);

% TRANSFORM THE IMAGE TO BYTE
image = image -128;
%% Write the image in the file input Java:
input_image_name = 'image.csv';
parent           = cd(compressed_image_path);
dlmwrite(input_image_name, image);
cd(parent);
 
 inputImagePath      = appendToPath(compressed_image_path,input_image_name);
 %inputImagePath      = normalizePathForJava(inputImagePath);
%outputs_java        = normalizePathForJava(ciphered_image_path);
outputs_java        = ciphered_image_path;

%% JAVA PART:
% javaCipheringLauncher(binPath,className,cipherType,input_path,output_path,ligne,colonne)
javaCipheringLauncher(binPath,cipherClass,cipherMode,inputImagePath,outputs_java,ligne_cr,colonne);

%% READ CIPHERED IMAGE OUTPUT BY JAVA: 
imageCipheredPath = appendToPath(ciphered_image_path,'imageCiphered');
parent = cd(imageCipheredPath);
image = dlmread('imageCiphered.csv');
cd(parent);

%% Steganography instertion:
image_hote  = imread('image_hote.png');
image_stego = stega(image_hote,image);

%% FIN DE LA SIMULATION POUR LA PREMIERE PARTIE

%% STEGANOGRAPHY EXTRACTION:
image = istega(image_stego);
image = round(image);
%% Path Variables for imageDeCiphering
imageToDecipherPath = '/usr/local/MATLAB/R2018b/bin/SimulCS/imageToDecipher/';
parent =cd(imageToDecipherPath);
dlmwrite('imageToDecipher.csv', image);
cd(parent)

%% Partie 2 Java:
%% PARAMETERS:
binPath = '/root/eclipse-workspace/Article4_QuantumCipherMode2/bin';
decipherClass = 'main_pkg.DeCipher';
cipheringType = cipherModes{1};
%parametersPath = normalizePathForJava(ciphered_image_path);
parametersPath = ciphered_image_path;
% imageToDecipherPath = normalizePathForJava(appendToPath(imageToDecipherPath,'imageToDecipher.csv'));
imageToDecipherPath = appendToPath(imageToDecipherPath,'imageToDecipher.csv');

javaDecipheringLauncher(binPath,decipherClass,cipheringType,parametersPath,imageToDecipherPath,ligne_cr,colonne)
%% -----------------------------------------------------------------------------------------------------%%
%% READ FINAL OUTPUT
parent = cd('/usr/local/MATLAB/R2018b/bin/SimulCS/output_java/finalOutput');
image = dlmread('finalOutput.csv');
cd(parent);
%% STEGA INVERSE:
%% Inverse de la quantification + 128
image = image + 128; 
image = invQuantification(image,max_im,min_im);

%% Reconstruction de l'image:
message =sprintf('Choix de la methode de reconstuction: \n1- Orhtogonal Matching Pursuit MP\n2- Basis Pursuit\n3- BAYES\n\n Votre Choix: ');
methodChoice = 1;

switch(methodChoice)
    case 1 
        image = OMP_2D(image,sensing_matrix,ligne,colonne);
    case 2
        image = BP_2D(image,sensing_matrix,ligne,colonne);
    case 3
        image = BAYES_2D(image,sensing_matrix,ligne,colonne);
    otherwise
        error('Mauvais Choix!')
end

%% Inverse Zigzag
image = izigzag(image,x_0,y_0);

%% Inverse DWT

image = reshape(image,1,ligne*colonne);
image(1:S(1)*S(2))= CA;
image = waverec2(image,S,'haar');

app1 = imageComparator(image_hote,image_stego);
app = imageComparator(imagesource,image);







