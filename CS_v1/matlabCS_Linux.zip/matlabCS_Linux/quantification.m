function q = quantification(matrice,max,min) 
q= floor(255*(matrice - min)/(max-min));
end