function res = delimit(valeur,max,min)
    res = round(valeur *(max-min)+min);
end