function image = izigzag(z,x0,y0)
[Vmax, Hmax,~] = size(z);
posV=x0;
posH=y0;
Vmin =1;
Hmin =1;
z=z(:);
image = zeros(Vmax,Hmax);
    for ii = 1:length(z)
        image(posV,posH)= z(ii);
        %% Si on n'est pas encore à la fin:
        if(~(posH==Hmax && posV==Vmax))
            %% pahse de montée si PosV + posH est paire:
            if(mod(posV+posH,2)==0)
                if(posV == Vmin)
                    if(posH < Hmax)
                        posH = posH +1;
                    else
                        posV =posV + 1;
                    end
                elseif(posV>Vmin)
                    if(posH == Hmax)
                        posV = posV +1;
                    else
                        posV = posV - 1;
                        posH = posH + 1;
                    end
                end
            else
                if(posV == Vmax)
                    posH = posH+1;
                elseif(posV<Vmax)
                    if(posH == Hmin)
                        posV = posV+1;
                    elseif(posH>Hmin)
                        posH =posH-1;
                        posV = posV+1;
                    end
                end
            end
        else
            posH =1;
            posV =1;
         end
    end
end