function winPath = normalizePathForJava(matlabFilelePath)
    winPath = sprintf('"%s"',replace(matlabFilelePath,filesep,'\\'));
end