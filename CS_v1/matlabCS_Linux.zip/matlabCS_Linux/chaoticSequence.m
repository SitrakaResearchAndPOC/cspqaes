function g_n = chaoticSequence(inidice,d,n,g0,r)
%% génération de la fonction de probabilité:
%% VARIABLE :
%% - L: position dans la matrice de mesure

%% CONSTANTES:
%% - n: nombre de colonne de de la matrice de mesure
%% - d: distance d'échantillonage
%% - r: rayon d'echantillonnage
%% - g0: valeur initiale

% densite_de_probabilite=zeros(1,L+1);
% sprintf('Paramètres d''entrée: \n- %03d.\n- %03d.\n- %03d.\n- %.3f. \n- %.3f.',n,d,L,r,g0)
%% Je calcule jusqu'a g(n + Ld)
    if(isempty(nargin))
        clear g pos;
    end
    
    persistent g;
    persistent pos;
    
    if(isempty(g))
        g = g0;
    end
    if(isempty(pos))
        pos = 1;
    end
    final_pos = inidice*d + n;
    
    for ii = pos:final_pos
        if ((g >= 0) && (g < r))
            g=g/r;
        elseif((g >= r) && (g<=1) )
            g = (1-g)/(1-r); 
        end
    end
    g_n = g;
    pos = final_pos;
%    sprintf('g[%d] = %.2f',pos,g)
end