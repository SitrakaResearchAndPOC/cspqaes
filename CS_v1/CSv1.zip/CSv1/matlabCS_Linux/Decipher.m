%% PARAMETERS TO CHANGE: 
chemin = 'D:\ECLIPSE_PROJECT\Article4_QuantumCipherMode2\bin';
nom_classe = 'main_pkg.DeCipher';
type_de_chiffrement = 'PQAES_SHAKE';
input_path = '"C:\\Users\\Sitraka\\Documents\\MATLAB\\Simulaka mila vitaina\\output_java"';
ligne = 192;
colonne = 256;

command = sprintf('java -cp %s %s %s %s %d %d',chemin, nom_classe,type_de_chiffrement,input_path,ligne,colonne);
[r,s] = system(command);
disp(s)