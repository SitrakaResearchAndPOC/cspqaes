function x=cs_omp(y,phi)
% y = phi*x
% phi：Matrice de mesure
% N：Nombre de colonne de phi

N = size(phi,2);
x = zeros(1,N);
A_t=[]; % Solution
r_t=y; % Résidu
inds = [];

for t=1:N
    coeff = abs(phi'*r_t);
    [~,ind] = max(coeff);
    A_t = [A_t, phi(:,ind)];
    phi(:,ind) = 0;
    x_tmp = inv((A_t'*A_t))*A_t'*y;
    r_t = y-A_t*x_tmp;
    inds = [inds, ind];
    if norm(r_t) < 1e-9
        break
    end
end
x(inds) = x_tmp;