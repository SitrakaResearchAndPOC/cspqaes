function [imsecrete,IT] = istega(imStego)
 [LL,LH,HL,~] = dwt2(imStego,'haar');

    [m,n] = size(imStego);

    % on suppose que image = [m/4,n]
    D1 = zeros(m/2,n/2);
    D2 = zeros(m/2,n/2);
    IT = zeros(m/2,n/2);

    MV = median(LL,'all');
    for ii = 1:m/2
        for jj = 1:n/2
            if LL(ii,jj) >= MV
                IT(ii, jj) = 1;
                D1(ii, jj) = LH(ii, jj);
                D2(ii, jj) = HL(ii, jj);
            else
                IT(ii, jj) = 0;
                D2(ii, jj) = LH(ii, jj);
                D1(ii, jj) = HL(ii, jj);
            end
        end
    end
    imsecrete = (D1 + 10*D2);
    imsecrete = reshape(imsecrete,m/4,n);
end