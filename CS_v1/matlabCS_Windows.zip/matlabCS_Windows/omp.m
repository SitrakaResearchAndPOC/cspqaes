function signalRec=omp(vectMes,matSensing)
    %% fonction qui effectue la reconstruction du signal par l'OMP

    %% Param�tres d'entr�es:
    % -> vectMes: vecteur de mesure M x 1 
    % -> matSensing: Matrice sensing M x N*

    %% Param�tres de sorties
    % -> signalRec: signal reconstruit
    
    [M,N]=size(matSensing);                                       
    signalRec=zeros(1,N);                                                      
    Aug_t=[];                                         
    r_n=vectMes;                                            


    for times=1:M                                    
        for col=1:N                                  
            product(col)=abs(matSensing(:,col)'*r_n);          
        end
        [val,pos]=max(product);                       
        Aug_t=[Aug_t,matSensing(:,pos)];                       
        matSensing(:,pos)=zeros(M,1);                          
        aug_y=(Aug_t'*Aug_t)^(-1)*Aug_t'*vectMes;          
        r_n=vectMes-Aug_t*aug_y;                           
        pos_array(times)=pos;                        
        
        if (abs(aug_y(end))^2/norm(aug_y)<0.05)       
            break;
        end
    end

    signalRec(pos_array)=aug_y;                           
end